BFG relationale Zusammensetzung und Balancezustand
30. September 2026

Dieses Rechenpaket prüft eine ausdrücklich vorgeschlagene BFG-Erweiterung.
Die zusätzlichen Regeln R1 (Relationsabschluss), R2 (Relationsmetrik) und
R3 (neutraler Gleichlauf) sind im begleitenden Dokument offengelegt.
Sie werden nicht als bereits bewiesene Konsequenzen des historischen Level 0
ausgegeben. Keine HLV-, Spiralzeit- oder SIEL-Annahme wird verwendet.

Ausführung der mathematischen Prüfung
    python3 verify_relational.py

Abhängigkeiten des Prüflaufs
    Python 3.12 oder kompatibel; NumPy
    Standardbibliothek fractions für exakte rationale Zeilenreduktion

Der Prüflauf erzeugt results.json. Er verwendet 96 Quellenvarianten und
je fünf G0-Fortsetzungen. Der Seed ist 300920264. Dies sind synthetische
Rechenprüfungen; es werden keine experimentellen Einzelereignisse simuliert.

source/g0_model.py ist bytegleich mit dem bereits vorhandenen reellen G0-Modul.
SHA256 c87a313ac59140afa55ce8fa5e11d1f80583747c5200804dbe85e6377aeb4929

Der komplexe Relationsraum wird algebraisch konstruiert. G0 wird ausschließlich
auf seinem expliziten reellen Hermiteschen Sektor ausgeführt. Der volle komplexe
Raum hat im quartischen Minimum eine reelle Phasennullrichtung; eine positive
Hesse-Matrix auf dem vollen Raum wird ausdrücklich nicht behauptet.

Die ausgewiesene geometrische CHSH-Kombination ist keine eigenständig aus G0
hergeleitete Messstatistik. Die Messannahmen der früheren Ausarbeitung bleiben
zusätzlich erforderlich.

build_report.py erzeugt das begleitende DOCX mit nativen Word-Gleichungen.
Zusätzliche Abhängigkeiten dafür: python-docx, lxml, pandoc.
Die Erzeugung wird hier bereitgestellt; die gerenderte Sichtprüfung des DOCX
gehört zum ursprünglichen Erstellungslauf.
