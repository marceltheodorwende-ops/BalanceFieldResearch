"""Create the BFG relational composition supplement with editable mathematics."""
from pathlib import Path
import copy, json, subprocess, zipfile
from lxml import etree
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
AS=ROOT/'assets';AS.mkdir(exist_ok=True)
results=json.loads((ROOT/'results.json').read_text())
E={
'local':r'\mathcal H_1\simeq\mathcal H_2\simeq\mathbb C^2,\qquad \mathcal A_j=\operatorname{alg}_{\mathbb C}\{P_+,P_-,C,C^\dagger\}=M_2(\mathbb C).',
'space':r'0\ne\mathcal R\subseteq\operatorname{Hom}_{\mathbb C}(\mathcal H_2,\mathcal H_1),\qquad \mathcal A_1\mathcal R\mathcal A_2\subseteq\mathcal R.',
'units':r'E_{ia}R_0E_{bj}=(R_0)_{ab}E_{ij},\qquad \mathcal R=M_2(\mathbb C),\qquad \dim_{\mathbb C}\mathcal R=4.',
'metric':r'\langle R,S\rangle_{\mathrm{rel}}=\operatorname{tr}(R^\dagger S),\qquad \|R\|_{\mathrm{rel}}^2=\sum_{i,j}\lvert R_{ij}\rvert^2.',
'vec':r'\mathcal R\simeq\mathcal H_1\otimes\mathcal H_2^{\mathrm c},\qquad \operatorname{vec}(R)=\sum_{i,j}R_{ij}\,e_i\otimes e_j^{\mathrm c}.',
'action':r'\operatorname{vec}(A R B)=(A\otimes B^{\mathsf T})\operatorname{vec}(R).',
'match':r'T:\mathcal H_2\to\mathcal H_1,\quad T^\dagger T=I,\quad A_T=TAT^\dagger,\qquad A_T R=R A\quad(A=A^\dagger).',
'comm':r'Z S=S Z\ \Longrightarrow\ S=\operatorname{diag}(a,d),\qquad X S=S X\ \Longrightarrow\ a=d,\qquad S=T^\dagger R.',
'neutral':r'R_*=\frac{e^{i\theta}}{\sqrt2}T,\qquad \phi_T=\frac{\operatorname{vec}(T)}{\sqrt2},\qquad Q_T=\phi_T\phi_T^\dagger.',
'bell':r'T=I:\qquad \phi_I=\frac{e_0\otimes e_0^{\mathrm c}+e_1\otimes e_1^{\mathrm c}}{\sqrt2}.',
'reduced':r'R_*R_*^\dagger=\frac I2,\qquad (R_*^\dagger R_*)^{\mathsf T}=\frac I2,\qquad \lvert\det R_*\rvert=\frac12.',
'axes':r'\sigma_1=X=\begin{pmatrix}0&1\\1&0\end{pmatrix},\quad\sigma_2=Y=\begin{pmatrix}0&-i\\i&0\end{pmatrix},\quad\sigma_3=Z=\begin{pmatrix}1&0\\0&-1\end{pmatrix}.',
'cost':r'\mathcal E_{\mathrm{rel}}(R)=\frac g4\sum_{j=1}^3\|\sigma_jR-R\sigma_j\|_{\mathrm{rel}}^2=\frac12\langle R,\mathcal L R\rangle_{\mathrm{rel}},\qquad g>0.',
'load':r'\mathcal L R=\frac g2\sum_{j=1}^3[\sigma_j,[\sigma_j,R]]=4g\left(R-\frac{\operatorname{tr}R}{2}I\right).',
'ambient':r'L=g\left(3I_4-\sum_{j=1}^3\sigma_j\otimes\sigma_j^{\mathsf T}\right)=4g(I_4-Q_I).',
'frame':r'R\mapsto U R V^\dagger,\quad T\mapsto U T V^\dagger,\quad \phi_T\mapsto(U\otimes V^{\mathrm c})\phi_T.',
'capacity':r'\mathfrak c=0,\quad N=\nu I+L,\quad\mathfrak D=(\nu+\kappa)I,\quad K=-\kappa I+L,\quad g,\kappa>0,\quad0<\nu<2\kappa.',
'quartic':r'F_0(r)=-\frac\kappa2\|r\|^2+\frac12r^\dagger Lr+\frac14\|r\|^4\ \ge\ -\frac{\kappa^2}{4}.',
'minima':r'F_0(r)=-\frac{\kappa^2}{4}\ \Longleftrightarrow\ r=\sqrt\kappa\,e^{i\theta}\phi_T.',
'hessian':r'H_{\mathbb R}=L_{\mathbb R}+2\kappa P_{\phi_T}^{\mathbb R},\qquad H_{\mathbb R}(i\phi_T)=0.',
'hspec':r'\operatorname{spec}H_{\mathbb R}=\{0,\ 2\kappa,\ 4g,\ 4g,\ 4g,\ 4g,\ 4g,\ 4g\}.',
'section':r'\mathcal S=\operatorname{Herm}(2,\mathbb C)=\operatorname{span}_{\mathbb R}\left\{\frac I{\sqrt2},\frac X{\sqrt2},\frac Y{\sqrt2},\frac Z{\sqrt2}\right\}\simeq\mathbb R^4.',
'realH':r'L_{\mathcal S}=\operatorname{diag}(0,4g,4g,4g),\quad H_{\mathcal S}=\operatorname{diag}(2\kappa,4g,4g,4g).',
'loadY':r'Y_N=\operatorname{diag}\left(\left(\frac\nu{2\kappa}\right)^2,\left(1+\frac\nu{4g}\right)^2,\left(1+\frac\nu{4g}\right)^2,\left(1+\frac\nu{4g}\right)^2\right).',
'selector':r'Q_{<1}=e_0e_0^{\mathsf T},\qquad \mathcal Q_{<1}(R)=\frac{\operatorname{tr}R}{2}I\quad(R\in\mathcal S).',
'seed':r'R_0=P_+=\begin{pmatrix}1&0\\0&0\end{pmatrix},\quad\mathcal Q_{<1}(R_0)=\frac I2,\quad\frac{\mathcal Q_{<1}(R_0)}{\|\mathcal Q_{<1}(R_0)\|}=\frac I{\sqrt2}.',
'densities':r'w_0=\frac{(1,0,0,1)^{\mathsf T}}{\sqrt2},\quad \rho_W=w_0w_0^{\mathsf T},\quad\rho_F=2\kappa\rho_W,\quad m=\operatorname{tr}(Q_{<1}\rho_W)=\frac12.',
'fixed':r'(\mathfrak c_+,N_+,\mathfrak D_+,\rho_{F,+},\rho_{W,+})=(0,\nu,\nu+\kappa,\kappa,1),\qquad Y_{N,+}=\left(\frac\nu{2\kappa}\right)^2.',
'corr':r'\mathcal C(\alpha,\beta)=\phi_I^\dagger\bigl(M(\alpha)\otimes M(\beta)\bigr)\phi_I=\frac12\operatorname{tr}\bigl(M(\alpha)M(\beta)^{\mathsf T}\bigr).',
'M':r'M(\alpha)=\cos\alpha\,Z+\sin\alpha\,X,\qquad \mathcal C(\alpha,\beta)=\cos(\alpha-\beta).',
'chsh':r'\alpha_0=0,\ \alpha_1=\frac\pi2,\ \beta_0=\frac\pi4,\ \beta_1=-\frac\pi4,\qquad \mathcal S_{\mathrm{geom}}=2\sqrt2.',
'bornbridge':r'w_{st}=\| (\Pi_s\otimes\Pi_t)\phi_I\|^2,\quad \Pi_s=\frac{I+sM}{2},\qquad p_{st}=w_{st}\ \text{erst unter Messannahmen}.',
}
(AS/'equations.md').write_text('\n\n'.join('$$\n'+v+'\n$$' for v in E.values()))
subprocess.run(['pandoc',str(AS/'equations.md'),'-o',str(AS/'equations.docx')],check=True)
with zipfile.ZipFile(AS/'equations.docx') as z:
    root=etree.fromstring(z.read('word/document.xml'))
math=root.xpath('//m:oMath',namespaces={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'})
assert len(math)==len(E)
native=dict(zip(E,math))
doc=Document();s=doc.sections[0]
s.page_width=Inches(8.5);s.page_height=Inches(11)
s.left_margin=s.right_margin=Inches(.7);s.top_margin=s.bottom_margin=Inches(.6)
for name,size in [('Normal',11),('Title',21),('Subtitle',11.5),('Heading 1',14),('Heading 2',11.5)]:
    st=doc.styles[name];st.font.name='Cambria';st.font.size=Pt(size)
    st.font.color.rgb=RGBColor(0,0,0);st.paragraph_format.space_after=Pt(5)
for st in doc.styles:
    for b in st.element.xpath('.//w:pBdr'):b.getparent().remove(b)
doc.styles['Normal'].paragraph_format.line_spacing=1.03
doc.core_properties.title='BFG Zusammensetzung durch neutrale Relationen'
doc.core_properties.author='Mathematische Ausarbeitung für Marcel Theodor Wende'
footer=s.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
counter=0
def p(t,bold=False):
    q=doc.add_paragraph();q.add_run(t).bold=bold;return q
def h(t):doc.add_heading(t,level=1)
def page():doc.add_page_break()
def eq(k):
    global counter
    counter+=1;q=doc.add_paragraph();q.alignment=WD_ALIGN_PARAGRAPH.CENTER
    q.paragraph_format.space_before=Pt(2);q.paragraph_format.space_after=Pt(6)
    q._p.append(copy.deepcopy(native[k]));q.add_run('   ('+str(counter)+')').font.size=Pt(8)
def table(head,rows,widths):
    t=doc.add_table(rows=1,cols=len(head));t.autofit=False
    for i,(txt,w) in enumerate(zip(head,widths)):
        t.columns[i].width=Inches(w);t.rows[0].cells[i].text=txt
    for row in rows:
        for c,txt in zip(t.add_row().cells,row):c.text=txt
    for ri,row in enumerate(t.rows):
        pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        for c,w in zip(row.cells,widths):
            c.width=Inches(w);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            pr=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
            for side in ['top','left','bottom','right']:
                x=OxmlElement('w:'+side);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');b.append(x)
            pr.append(b);mar=OxmlElement('w:tcMar')
            for side in ['top','left','bottom','right']:
                x=OxmlElement('w:'+side);x.set(qn('w:w'),'80');x.set(qn('w:type'),'dxa');mar.append(x)
            pr.append(mar);sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'DCE6EC' if ri==0 else 'FFFFFF');pr.append(sh)
            for q in c.paragraphs:
                q.paragraph_format.space_after=Pt(2);q.paragraph_format.line_spacing=1.02
                for run in q.runs:run.font.size=Pt(9.5);run.bold=ri==0
    t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

doc.add_paragraph('BFG Zusammensetzung durch neutrale Relationen','Title')
doc.add_paragraph('Bedingte Herleitung der Bell Form und Anschluss an Level Null','Subtitle')
p('Ausarbeitung für Marcel Theodor Wende · 30. September 2026')
p('Ergebnis. Aus dem zweidimensionalen komplexen BFG-Träger lässt sich eine gemeinsame Relation zweier Systeme aufbauen. Wird ihre lineare Abschlussregel unter unabhängigen Operationen an beiden Enden festgelegt, entsteht ein vierdimensionaler komplexer Relationsraum. Eine zusätzlich präzisierte neutrale Gleichlaufbedingung bestimmt darin eine einzige normierte Richtung bis auf die Gesamtphase. In angeglichenen Polkoordinaten besitzt sie die Bell-Form.')
p('Die Herleitung führt diese Richtung als Lösung einer Relationsgleichung ein. Ein positiv semidefiniter Abweichungsoperator setzt die Bedingung in das quartische BFG-Formationsfunktional ein. In einem ausdrücklich reellen Relationssektor wählt L0+ die Richtung aus, und die bereits vorgeschlagene G0-Fortsetzung erhält sie exakt. Die neue Zusammensetzungsregel und der gemeinsame Gleichlauf sind konstitutive Ergänzungen; sie werden nicht als bereits bewiesene Folgen des historischen Level 0 ausgegeben.')
h('1 Herkunft der Voraussetzungen')
table(['Baustein','Mathematischer Status'],[
('Lokaler Träger','Komplexe Hilbertstruktur, zwei orthogonale Polvertreter und lokale Operatoren aus dem Carrier-Paper [1].'),
('Formation und neutrale Last','Reelles quartisches Funktional und ausdrücklich ergänztes L0+ aus [2].'),
('Fortsetzung','Die vorgeschlagene reelle G0-Regel aus [3], unverändert verwendet.'),
('R1 Relationsabschluss','Neue Regel: nichtnull, komplex-linear und unter beidseitigen lokalen Operatoren abgeschlossen.'),
('R2 Relationsmetrik','Neue Symmetrieannahme: unabhängige unitäre Endpunktwechsel erhalten dieselbe Metrik; keine weitere Endpunktmetrik.'),
('R3 Neutraler Gleichlauf','Neue Quellenbedingung: passende lokale Operationen stimmen durch eine unitäre Relation T hindurch überein; isotrope positive Abweichungskosten.'),
('Messstatistik','Die zusätzlichen Messannahmen aus [4] bleiben erforderlich und werden hier nicht als BFG-Folgerung verwendet.')],[1.55,5.55])
p('Die beiden Systeme heißen P₁ und P₂. Ihre jeweiligen zwei Pole sind von den zwei Systemen zu unterscheiden. Die Rechnung verwendet BFG-Quellen und elementare lineare Algebra. Der Benchmark [5] dient der Statuskontrolle, nicht als zusätzliches Naturgesetz. Die Identifikation einer Wirkungsskala S₀ mit einer gemessenen Konstante ist für die folgenden Relationssätze nicht erforderlich.')

page();h('2 Zusammensetzung aus dem Relationsabschluss')
p('Ausgangspunkt sind die Polprojektoren und die gerichtete Relation des Carrier-Papers [1, Gleichungen 10–14]. Ihre komplexe Algebra enthält alle vier Matrixeinheiten. Die dort verwendete Matrixdarstellung wird einschließlich ihrer orthogonalen Polbasis übernommen: Bloße lineare Unabhängigkeit zweier Pole allein würde diese Orthogonalität noch nicht beweisen.')
eq('local')
p('Regel R1. Eine gemeinsame Konfiguration wird durch eine lineare Relation R von H₂ nach H₁ dargestellt. Zulässige Relationen bilden einen nichtverschwindenden komplexen Unterraum und bleiben unter den lokal erzeugten Operatoren auf beiden Seiten erhalten:')
eq('space')
p('Satz 1. R1 erzwingt den vollständigen Relationsraum. Beweis. Wähle eine nichtverschwindende Relation R₀ und einen von null verschiedenen Eintrag mit Indizes a,b. Für beliebige i,j gilt:')
eq('units')
p('Damit liegt jede Matrixeinheit Eᵢⱼ im zulässigen Raum. Ihre vier komplexen Koeffizienten sind unabhängig, also ist der Raum genau M₂(C). Die Gleichung ist ein Abschlussbeweis. Dass gemeinsame physikalische Konfigurationen gerade als solche Relationen realisiert sind, ist der Inhalt der neuen Regel R1.')
p('Satz 2. R2 bestimmt jede positive hermitesche Relationsmetrik bis auf einen gemeinsamen Maßstab. Unabhängige Phasen der lokalen Basisvektoren multiplizieren Eᵢⱼ mit unterschiedlichen Phasenfaktoren. Invarianz erzwingt deshalb die Orthogonalität verschiedener Matrixeinheiten. Lokale Vertauschungen machen ihre vier Normen gleich. Nach Wahl der gemeinsamen Einheit folgt:')
eq('metric')
p('Dies ist die Hilbert-Schmidt-Metrik. R2 ist stärker als bloße Koordinatenkovarianz: Bei einer allgemeinen Metrik könnten ihre Komponenten beim Basiswechsel mittransformieren. Hier wird ausdrücklich das Fehlen einer zusätzlichen ausgezeichneten Endpunktmetrik verlangt.')
eq('vec');eq('action')
p('Das Tensorprodukt tritt damit als algebraische Darstellung des Relationsraums auf. Der zweite Faktor ist der konjugierte Träger, weil R am zweiten Ende kontravariant wirkt. Das hochgestellte c bezeichnet den konjugierten Träger beziehungsweise komponentenweise Konjugation. Die Transposition in der letzten Gleichung ist wesentlich; sie darf insbesondere bei der imaginären Relation Y nicht weggelassen werden.')

page();h('3 Die neutrale Relation bestimmt die gemeinsame Richtung')
p('Regel R3. Für zwei strukturell gleiche lokale BFG-Träger wird eine unitäre Zuordnung T ihrer Polrahmen angegeben. Neutraler Gleichlauf bedeutet: Eine lokale hermitesche Operation kann auf die jeweils andere Seite der Relation übertragen werden, ohne die gemeinsame Konfiguration zu ändern.')
eq('match')
p('Satz 3. Jede solche Relation ist R = cT. Beweis. Setze S = T†R. Die Gleichlaufgleichung fordert, dass S mit allen lokalen hermiteschen Operatoren kommutiert. Schon der Polkontrast Z und die Mischung X reichen aus:')
eq('comm')
p('Die Normierung aus Satz 2 bestimmt nun den Betrag des einzigen verbleibenden Koeffizienten. Da T unitär und zweidimensional ist, besitzt T die quadratische Norm 2. Daher gilt:')
eq('neutral');eq('bell')
p('Damit wird die Bell-Form aus dem neutralen Gleichlauf gewonnen. Der Faktor 1/√2 folgt aus der Relationsnorm. Die relative Gleichheit der beiden Koeffizienten folgt aus der Mischungsbedingung mit X. Die Gesamtphase verändert den Rang-eins-Projektor Q_T nicht.')
eq('reduced')
p('Der normierte Koeffizientenoperator hat Rang zwei und zwei gleiche Singularwerte. Ein Produktvektor hätte einen Koeffizientenoperator vom Rang eins. Der gemeinsame Vektor ist daher bezüglich der aus R1 erhaltenen Endpunktzerlegung nicht separierbar; seine beiden algebraischen Reduktionen sind I/2. Ihre Interpretation als lokale Messzustände benötigt zusätzlich die statistische Zuordnung.')
p('Warum beide Bedingungen nötig sind. Nur Z-Gleichlauf lässt jede Diagonalmatrix zu, einschließlich des Produktfalls diag(1,0). Auch die invertierbare Relation diag(1,2)/√5 erhält beide Polrichtungen, besitzt aber ungleiche Gewichte 1/5 und 4/5. Nichtfragmentierung allein erzwingt somit die Bell-Form nicht. Der zusätzliche Gleichlauf der Mischungen ist die entscheidende Anforderung.')
p('Die Wahl T = I bedeutet angeglichene Rahmen, nicht eine physikalisch bevorzugte absolute Orientierung. Ein anderes unitäres T liefert dieselbe Klasse gleicher Singularwerte. Die universellen BFG-Rollen bestimmen T und die Verwirklichung von R3 in einer konkreten Quelle bisher nicht.')

page();h('4 Ein positiver neutraler Operator für diese Bedingung')
p('Im Rahmen T = I sind die drei lokalen hermiteschen Richtungen X, Y und Z die bereits aus den BFG-Polen und der konjugierten Relation gewonnenen Matrizen. R3 bewertet ihre Gleichlaufabweichungen gleich. Für eine positive Kopplungsstärke g wird die quadratische Relationsenergie definiert:')
eq('axes');eq('cost');eq('load')
p('Beweis der letzten Identität. Für jede Matrix R gilt Σⱼ σⱼRσⱼ = 2 tr(R)I − R. Einsetzen in die doppelten Kommutatoren ergibt die angegebene Formel. Die Operatoren der Links- und Rechtsmultiplikation sind bezüglich der Relationsmetrik selbstadjungiert, sodass jede Summandennorm eine positive quadratische Form ist.')
eq('ambient')
p('Folglich hat L genau einen komplexen Nullmodus und die drei positiven Eigenwerte 4g. Sein Kern ist der zuvor gelöste neutrale Gleichlauf; der Bell-Vektor wird nicht als unabhängiger Zustandseingang in die Kostenfunktion gesetzt. Seine Auswahl ist dennoch bereits im Inhalt der starken Gleichlaufbedingung angelegt.')
p('Bedingte Eindeutigkeit. Jeder komplex-lineare selbstadjungierte Abweichungsoperator, der unter gemeinsamen unitären Rahmenrotationen invariant ist und die Identitätsrelation vernichtet, ist auf dem spurfreien Unterraum ein Skalar. Im Pauli-System erzwingen 180-Grad-Rotationen zunächst eine diagonale Form; 90-Grad-Rotationen gleichen die drei Diagonaleinträge an. Nichtdegenerierter Gleichlauf setzt diesen Skalar positiv. Damit ist die Form von L bis auf g bestimmt. Ohne Isotropie bleiben unterschiedliche positive Richtungsgewichte zulässig; die bloße BFG-Neutralitätsbezeichnung fixiert sie nicht.')
eq('frame')
p('Die Darstellung ist unabhängig von den gewählten lokalen Rahmen. Allgemein werden die drei linken und rechten Richtungen jeweils mit U und V transformiert. Die Abweichung AⱼR − RBⱼ und ihre Norm transformieren dann konsistent, und der Kern wird zur Linie durch UT V†. Diese Kovarianz schützt vor einer versehentlichen Bevorzugung numerischer Koordinaten.')
p('Zum bisherigen Modell. Die frühere reelle Rechnung [4] verwendete die beiden Richtungen X und Z. Die hier hergeleitete lokale BFG-Algebra enthält zusätzlich Y. Ihre gleichgewichtete Einbeziehung macht die drei transversalen Lasten gleich. Sie verändert die erklärte Quellenkopplung; die Fortsetzungsregel G0 wird dadurch nicht verändert.')

page();h('5 Formation und die Grenze der komplexen Erweiterung')
p('Mit dem neuen Relationsoperator lässt sich eine positive Kapazitätsfamilie im BFG-Formationsschema angeben. Der Parameterbereich wird vor der Auswahl festgelegt:')
eq('capacity')
p('Für allgemeines T ist L = 4g(I − Q_T). Mit r = vec(R) erhält man auf dem gesamten komplexen Relationsraum zunächst folgendes reelle Energieproblem:')
eq('quartic');eq('minima')
p('Beweis. L ist positiv und verschwindet genau auf der neutralen Linie. Die skalare Funktion −κr²/2 + r⁴/4 besitzt ihr Minimum −κ²/4 bei r² = κ. Gleichheit verlangt gleichzeitig die neutrale Richtung und diesen Radius. Alle normierten Minimierer besitzen daher denselben Projektor Q_T.')
p('Wichtiger Anschlussbefund. Das integrierte L0+-Paper [2] formuliert seinen strikten Hesse-Satz auf einem reellen Träger mit einfachem Grundmodus. Der komplexe Raum besitzt dagegen eine ganze Kreisfamilie von Minima. Der korrekte reelle Hesse-Operator am Vertreter √κ φ_T lautet:')
eq('hessian');eq('hspec')
p('Dabei ist P mit oberem R die Projektion auf die eine reelle Radialrichtung φ_T. Die Richtung iφ_T ist die gemeinsame Phase und kostet am Minimum keine Energie. Der Hesse-Operator ist deshalb auf dem vollen acht reellen Dimensionen singulär. Die reelle L0+-Formel durch bloßes Ersetzen von Transpositionen durch Adjungieren auf diesen Raum zu übertragen, wäre falsch.')
p('Ein Quotient nach der Gesamtphase würde lokal sieben reelle Tangentenrichtungen besitzen. Ein vollständig definierter G0-Nachfolger auf diesem Quotienten ist in den geprüften Quellen nicht gegeben und wird hier nicht behauptet. Für den direkten Anschluss an die bereits geprüfte BFG-Fortsetzung wählen wir deshalb auf der nächsten Seite einen expliziten vierdimensionalen reellen Relationssektor.')
p('Diese Einschränkung ist mathematisch sichtbar. Sie entfernt neben der gemeinsamen Phasenrichtung auch die drei imaginären spurfreien Richtungen. Sie ist daher mehr als eine bloße Wahl der Gesamtphase. Die volle komplexe Trägerkonstruktion und die nachfolgende reelle G0-Realisierung haben unterschiedliche Geltungsbereiche.')

page();h('6 Exakte Auswahl und Fortsetzung im reellen Relationssektor')
p('Auf dem folgenden reellen Unterraum sind die Formation und die positive lokale Hesse-Matrix genau vom Typ des integrierten L0+-Papers. Die Pauli-Matrix Y besitzt zwar imaginäre Einträge, ihre Koeffizienten in diesem Sektor sind aber reell:')
eq('section');eq('realH')
p('In anderen lokalen Rahmen wird dieser Sektor zu {UHV† : H = H†}. Für T = UV† ist dies äquivalent zur Bedingung RT† = TR†. Die Sektorwahl bleibt somit bei konsistent mittransformierter Relation wohldefiniert. Sie beansprucht keine vollständige Beschreibung aller komplexen gemeinsamen Zustände.')
p('Satz 4. L0+ und der strikte G0-Selektor wählen in diesem Sektor genau die neutrale Richtung. Beweis. H und N sind in der angegebenen orthonormalen Basis diagonal. Die Definition der neutralen Last aus L0+ ergibt:')
eq('loadY');eq('selector')
p('Wegen 0 < ν < 2κ liegt nur der erste Lastwert unter eins. Ein konkreter anfangs separierbarer Relationszustand wird dadurch wie folgt ausgewählt und normiert:')
eq('seed')
p('Der Koeffizientenvektor von R₀ in der oben angegebenen Basis bestimmt die beiden anfänglichen G0-Dichten:')
eq('densities')
p('Satz 5. Die unveränderte G0-Regel [3] führt diesen Anfangszustand nach einem Schritt auf den eingebetteten neutralen Rang-eins-Zustand. Ihre aktiven Kapazitäten und Dichten sind:')
eq('fixed')
p('Beweis. Der Selektor lässt nur e₀ übrig. Die zwei Analysezweige sind deshalb kollinear; ihre normierte polare Einbettung komprimiert jede doppelt geerbte Kapazität auf ihren Wert in dieser Richtung. Die Formationsmasse wird κ, der normalisierte Zeuge wird 1. Im aktiven Skalarraum gilt K₊ = −κ und H₊ = 2κ. Damit bleiben alle Größen bei jeder weiteren G0-Anwendung gleich. Induktion beweist die Persistenz für beliebig viele Schritte.')
p('Dies ist eine Auswahl mit normierter Fortsetzung, kein für alle Eingänge normerhaltendes Gatter. Die überlebende Zeugenmasse 1/2 ist ohne Messzuordnung keine Erfolgswahrscheinlichkeit. Spurfreie Eingangszustände überleben diese Auswahl nicht. Auch ein allgemeiner Attraktor mit Korrektur beliebiger Massenfehler wird nicht bewiesen.')

page();h('7 Anschluss an das Messmodell')
p('Die Zusammensetzungsrechnung bestimmt einen gemeinsamen Träger, eine neutrale Richtung und eine zulässige reelle Präparation. Lokale Operatoren werden auf dem eingebetteten Relationsraum ausgewertet. Der aktive G0-Skalar allein kann die lokalen Algebren nicht darstellen. Für die XZ-Messungen ist der erhaltene Eingang derselbe reelle Bell-Vektor wie in [4]; die Registrierung muss nicht im hermiteschen Relationssektor verbleiben.')
eq('corr');eq('M')
p('Der Ausdruck ist zunächst eine normierte quadratische Relationsgröße. Im reellen XZ-Sektor ergibt die direkte Spurrechnung den Kosinus der Winkeldifferenz. Für die vier bereits verwendeten Einstellungen folgt:')
eq('chsh')
p('Dabei bedeutet S_geom die Kombination C₀₀ + C₀₁ + C₁₀ − C₁₁ dieser vier geometrischen Werte. Eine experimentelle CHSH-Verletzung verlangt zusätzlich, dass C die Korrelation tatsächlich gezählter Einzelereignisse ist. Diese Bedeutung wird durch die Relationsalgebra allein nicht festgelegt.')
eq('bornbridge')
p('Das bisherige Messmodell [4] führt dazu zwei zusätzliche Anforderungen ein: Die Wahrscheinlichkeit eines idealen Kanals hängt nur von seiner normierten Masse ab, und eine verlustfreie Aufteilung in orthogonale Unterkanäle erhält die aufsummierte Wahrscheinlichkeit. Zusammen mit Normierung und Nichtnegativität erzwingen sie durch rationale Verfeinerung und Monotonie p = w. Die vorliegende Zusammensetzung beweist diese statistischen Anforderungen nicht neu.')
p('Warum die Unterscheidung erforderlich bleibt. Zu denselben Zweigmassen wäre zunächst auch pⱼ = wⱼ² / Σₖwₖ² definierbar. Bei zwei Halbgewichten beträgt die erste Wahrscheinlichkeit dann 1/2. Wird das erste Halbgewicht in zwei Viertelgewichte zerlegt, beträgt die zusammengefasste Wahrscheinlichkeit nur noch 1/3. Die zusätzliche Verfeinerungsanforderung schließt diese Zuordnung aus; der bare Relationsraum enthält eine solche Forderung noch nicht.')
p('Die zweite Trägerkopie bleibt konjugiert. In Standardkoordinaten besitzt der erhaltene Vektor die drei Korrelationen (+1, −1, +1) für X⊗X, Y⊗Y, Z⊗Z. Wer am zweiten Ende den ursprünglich gegebenen Operator Y überträgt, erhält durch die Konjugation Yᵀ = −Y. Das Pluszeichen der ursprünglichen Gleichlaufbedingung widerspricht deshalb der negativen Y⊗Y-Korrelation nicht.')
p('Für eine vollständig BFG-interne Ereignistheorie bleiben eine konkrete Registrierung, ihre Wahrscheinlichkeitszuordnung und das Auftreten eines einzelnen Ergebnisses zu begründen. S₀ aus dem Carrier-Paper verbindet Energie und Phase; diese Beziehung bestimmt für sich keine Zählstatistik. Die nun bewiesene Relationskonstruktion liefert den präziseren Ausgangspunkt für diesen weiteren Schritt.')

page();h('8 Rechenprüfung und verwendete Quellen')
p('Die Beweise wurden durch exakte Matrixidentitäten und numerische Varianten geprüft. Die Matrixeinheiten, die Lastformel und die Kerndimensionen werden mit kleinen exakt darstellbaren Gaußschen Ganzzahlen beziehungsweise rationaler Zeilenreduktion kontrolliert. Die Aussagen für beliebige positive Parameter folgen aus den oben angegebenen Beweisen; die Stichproben dienen ihrer unabhängigen Gegenprüfung.')
table(['Prüfung','Ergebnis'],[
('Quellen und lokale Rahmen','96 Varianten mit verschiedenen κ, ν, g sowie unabhängig gewechselten unitären Endpunktrahmen.'),
('Unveränderte G0-Fortsetzung','Je fünf Schritte, insgesamt 480 erfolgreiche Fortsetzungen; Richtung und Formationsmasse entsprechen dem Fixpunktsatz.'),
('Größter numerischer Restfehler',f"{results['max_residual']:.3g}; alle vorgegebenen Prüfgrenzen eingehalten."),
('Reelles Beispiel κ = 2, ν = 1, g = 1','H = diag(4,4,4,4); Y_N = diag(1/16,25/16,25/16,25/16).'),
('Komplexe Gegenprüfung','Die volle reelle Hesse-Matrix besitzt Rang sieben; die Gesamtphase bleibt eine Nullrichtung.'),
('Entfernung der Mischung','Nur Z-Gleichlauf lässt einen zweidimensionalen Kern und den Produktfall diag(1,0) zu.'),
('Geometrische Korrelationskombination','2.8284271247461903; als CHSH-Zählstatistik weiterhin bedingt durch Messannahmen.')],[2.1,5.0])
p('Das Rechenpaket enthält den vollständigen Prüflauf, die Resultate, den unveränderten G0-Quelltext und den Dokumentgenerator. Es verwendet Python '+results['environment']['python']+' und NumPy '+results['environment']['numpy']+'. Es wurden keine experimentellen Daten ausgewertet. Die Zahlen sind mathematische Rechenprüfungen, keine Bestätigung einer natürlichen Realisierung.')
p('Erreichter Status. Unter R1 bis R3 ist die gemeinsame Bell-förmige Balance mathematisch festgelegt. Der reelle L0+- und G0-Anschluss ist vollständig ausgeführt. Die Ableitung der komplexen Hilbertstruktur aus einem voraussetzungsloseren Level 0, eine allgemeine komplexe Fortsetzung und eine eigenständige Ereignisstatistik bleiben davon getrennte Aufgaben. Die Zusatzregeln werden durch ihre Benennung als BFG-Erweiterung nicht rückwirkend zu Theoremen des alten Kerns.')
p('Quellen',True)
refs=[
'[1] Marcel Theodor Wende. Minimal Carrier and Action-Scale Closure in the Balance–Field Framework. 22.09.2026. Besonders Abschnitte 2–8 und Anhang A.',
'[2] Marcel Theodor Wende. BFG Neutral First Reclosure and the Conditions for Emergence. Integriertes Preprint mit amended Level 0. Revidierte Fassung vom 30.09.2026. Besonders Abschnitt 2.',
'[3] BFG G0 als neues Fortsetzungsaxiom. Begründung und mathematische Folgen einer revidierten neutralen Rückkopplung. Ausarbeitung für Marcel Theodor Wende, 30.09.2026; dazu Geschlossene BFG Dynamik mit getrennter neutraler Last und das unveränderte Modul g0_model.py.',
'[4] BFG Messmodell mit neutraler Fortsetzung. Balancekopplung lokale Registrierung und bedingte Ergebniswahrscheinlichkeiten. Ausarbeitung für Marcel Theodor Wende, 30.09.2026. Besonders Abschnitte 2, 4 und 5.',
'[5] Marcel Theodor Wende. BFG Natural-Emergence Benchmark and Capacity-Matched Null-Model Tournament. 09.09.2026. Abschnitt Quantum Mechanics; historischer Prüfstand, keine Bewertung späterer Ergänzungen.'
]
for txt in refs:
    q=p(txt)
    for run in q.runs:run.font.size=Pt(9)
doc.save(OUT/'BFG_Relationale_Zusammensetzung_und_Balancezustand_2026-09-30.docx')
print(json.dumps({'document':str(OUT/'BFG_Relationale_Zusammensetzung_und_Balancezustand_2026-09-30.docx'), 'equations':counter},indent=2))
