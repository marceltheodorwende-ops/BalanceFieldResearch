"""Create the BFG relational composition supplement with editable mathematics."""
from pathlib import Path
import copy, json, subprocess, zipfile
from lxml import etree
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
AS=ROOT/'assets';AS.mkdir(exist_ok=True)
results=json.loads((ROOT/'results.json').read_text())
E={
'local':r'\mathcal H_1\simeq\mathcal H_2\simeq\mathbb C^2,\qquad \mathcal A_j=\operatorname{alg}_{\mathbb C}\{P_+,P_-,C,C^\dagger\}=M_2(\mathbb C).',
'space':r'0\ne\mathcal R\subseteq\operatorname{Hom}_{\mathbb C}(\mathcal H_2,\mathcal H_1),\qquad \mathcal A_1\mathcal R\mathcal A_2\subseteq\mathcal R.',
'units':r'E_{ia}R_0E_{bj}=(R_0)_{ab}E_{ij},\qquad \mathcal R=M_2(\mathbb C),\qquad \dim_{\mathbb C}\mathcal R=4.',
'metric':r'\langle R,S\rangle_{\mathrm{rel}}=\operatorname{tr}(R^\dagger S),\qquad \|R\|_{\mathrm{rel}}^2=\sum_{i,j}\lvert R_{ij}\rvert^2.',
'vec':r'\mathcal R\simeq\mathcal H_1\otimes\mathcal H_2^{\mathrm c},\qquad \operatorname{vec}(R)=\sum_{i,j}R_{ij}\,e_i\otimes e_j^{\mathrm c}.',
'action':r'\operatorname{vec}(A R B)=(A\otimes B^{\mathsf T})\operatorname{vec}(R).',
'match':r'T:\mathcal H_2\to\mathcal H_1,\quad T^\dagger T=I,\quad A_T=TAT^\dagger,\qquad A_T R=R A\quad(A=A^\dagger).',
'comm':r'Z S=S Z\ \Longrightarrow\ S=\operatorname{diag}(a,d),\qquad X S=S X\ \Longrightarrow\ a=d,\qquad S=T^\dagger R.',
'neutral':r'R_*=\frac{e^{i\theta}}{\sqrt2}T,\qquad \phi_T=\frac{\operatorname{vec}(T)}{\sqrt2},\qquad Q_T=\phi_T\phi_T^\dagger.',
'bell':r'T=I:\qquad \phi_I=\frac{e_0\otimes e_0^{\mathrm c}+e_1\otimes e_1^{\mathrm c}}{\sqrt2}.',
'reduced':r'R_*R_*^\dagger=\frac I2,\qquad (R_*^\dagger R_*)^{\mathsf T}=\frac I2,\qquad \lvert\det R_*\rvert=\frac12.',
'axes':r'\sigma_1=X=\begin{pmatrix}0&1\\1&0\end{pmatrix},\quad\sigma_2=Y=\begin{pmatrix}0&-i\\i&0\end{pmatrix},\quad\sigma_3=Z=\begin{pmatrix}1&0\\0&-1\end{pmatrix}.',
'cost':r'\mathcal E_{\mathrm{rel}}(R)=\frac g4\sum_{j=1}^3\|\sigma_jR-R\sigma_j\|_{\mathrm{rel}}^2=\frac12\langle R,\mathcal L R\rangle_{\mathrm{rel}},\qquad g>0.',
'load':r'\mathcal L R=\frac g2\sum_{j=1}^3[\sigma_j,[\sigma_j,R]]=4g\left(R-\frac{\operatorname{tr}R}{2}I\right).',
'ambient':r'L=g\left(3I_4-\sum_{j=1}^3\sigma_j\otimes\sigma_j^{\mathsf T}\right)=4g(I_4-Q_I).',
'frame':r'R\mapsto U R V^\dagger,\quad T\mapsto U T V^\dagger,\quad \phi_T\mapsto(U\otimes V^{\mathrm c})\phi_T.',
'capacity':r'\mathfrak c=0,\quad N=\nu I+L,\quad\mathfrak D=(\nu+\kappa)I,\quad K=-\kappa I+L,\quad g,\kappa>0,\quad0<\nu<2\kappa.',
'quartic':r'F_0(r)=-\frac\kappa2\|r\|^2+\frac12r^\dagger Lr+\frac14\|r\|^4\ \ge\ -\frac{\kappa^2}{4}.',
'minima':r'F_0(r)=-\frac{\kappa^2}{4}\ \Longleftrightarrow\ r=\sqrt\kappa\,e^{i\theta}\phi_T.',
'hessian':r'H_{\mathbb R}=L_{\mathbb R}+2\kappa P_{\phi_T}^{\mathbb R},\qquad H_{\mathbb R}(i\phi_T)=0.',
'hspec':r'\operatorname{spec}H_{\mathbb R}=\{0,\ 2\kappa,\ 4g,\ 4g,\ 4g,\ 4g,\ 4g,\ 4g\}.',
'section':r'\mathcal S=\operatorname{Herm}(2,\mathbb C)=\operatorname{span}_{\mathbb R}\left\{\frac I{\sqrt2},\frac X{\sqrt2},\frac Y{\sqrt2},\frac Z{\sqrt2}\right\}\simeq\mathbb R^4.',
'realH':r'L_{\mathcal S}=\operatorname{diag}(0,4g,4g,4g),\quad H_{\mathcal S}=\operatorname{diag}(2\kappa,4g,4g,4g).',
'loadY':r'Y_N=\operatorname{diag}\left(\left(\frac\nu{2\kappa}\right)^2,\left(1+\frac\nu{4g}\right)^2,\left(1+\frac\nu{4g}\right)^2,\left(1+\frac\nu{4g}\right)^2\right).',
'selector':r'Q_{<1}=e_0e_0^{\mathsf T},\qquad \mathcal Q_{<1}(R)=\frac{\operatorname{tr}R}{2}I\quad(R\in\mathcal S).',
'seed':r'R_0=P_+=\begin{pmatrix}1&0\\0&0\end{pmatrix},\quad\mathcal Q_{<1}(R_0)=\frac I2,\quad\frac{\mathcal Q_{<1}(R_0)}{\|\mathcal Q_{<1}(R_0)\|}=\frac I{\sqrt2}.',
'densities':r'w_0=\frac{(1,0,0,1)^{\mathsf T}}{\sqrt2},\quad \rho_W=w_0w_0^{\mathsf T},\quad\rho_F=2\kappa\rho_W,\quad m=\operatorname{tr}(Q_{<1}\rho_W)=\frac12.',
'fixed':r'(\mathfrak c_+,N_+,\mathfrak D_+,\rho_{F,+},\rho_{W,+})=(0,\nu,\nu+\kappa,\kappa,1),\qquad Y_{N,+}=\left(\frac\nu{2\kappa}\right)^2.',
'corr':r'\mathcal C(\alpha,\beta)=\phi_I^\dagger\bigl(M(\alpha)\otimes M(\beta)\bigr)\phi_I=\frac12\operatorname{tr}\bigl(M(\alpha)M(\beta)^{\mathsf T}\bigr).',
'M':r'M(\alpha)=\cos\alpha\,Z+\sin\alpha\,X,\qquad \mathcal C(\alpha,\beta)=\cos(\alpha-\beta).',
'chsh':r'\alpha_0=0,\ \alpha_1=\frac\pi2,\ \beta_0=\frac\pi4,\ \beta_1=-\frac\pi4,\qquad \mathcal S_{\mathrm{geom}}=2\sqrt2.',
'bornbridge':r'w_{st}=\| (\Pi_s\otimes\Pi_t)\phi_I\|^2,\quad \Pi_s=\frac{I+sM}{2},\qquad p_{st}=w_{st}\ \text{under measurement assumptions}.',
}
(AS/'equations.md').write_text('\n\n'.join('$$\n'+v+'\n$$' for v in E.values()))
subprocess.run(['pandoc',str(AS/'equations.md'),'-o',str(AS/'equations.docx')],check=True)
with zipfile.ZipFile(AS/'equations.docx') as z:
    root=etree.fromstring(z.read('word/document.xml'))
math=root.xpath('//m:oMath',namespaces={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'})
assert len(math)==len(E)
native=dict(zip(E,math))
doc=Document();s=doc.sections[0]
s.page_width=Inches(8.5);s.page_height=Inches(11)
s.left_margin=s.right_margin=Inches(.7);s.top_margin=s.bottom_margin=Inches(.6)
for name,size in [('Normal',11),('Title',21),('Subtitle',11.5),('Heading 1',14),('Heading 2',11.5)]:
    st=doc.styles[name];st.font.name='Cambria';st.font.size=Pt(size)
    st.font.color.rgb=RGBColor(0,0,0);st.paragraph_format.space_after=Pt(5)
for st in doc.styles:
    for b in st.element.xpath('.//w:pBdr'):b.getparent().remove(b)
doc.styles['Normal'].paragraph_format.line_spacing=1.03
doc.core_properties.title='BFG Composition through Neutral Relations'
doc.core_properties.language='en-US'
lang=OxmlElement('w:lang');lang.set(qn('w:val'),'en-US')
doc.styles['Normal'].element.get_or_add_rPr().append(lang)
doc.core_properties.author='Mathematical supplement prepared for Marcel Theodor Wende'
footer=s.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
counter=0
def p(t,bold=False):
    q=doc.add_paragraph();q.add_run(t).bold=bold;return q
def h(t):doc.add_heading(t,level=1)
def page():doc.add_page_break()
def eq(k):
    global counter
    counter+=1;q=doc.add_paragraph();q.alignment=WD_ALIGN_PARAGRAPH.CENTER
    q.paragraph_format.space_before=Pt(2);q.paragraph_format.space_after=Pt(6)
    q._p.append(copy.deepcopy(native[k]));q.add_run('   ('+str(counter)+')').font.size=Pt(8)
def table(head,rows,widths):
    t=doc.add_table(rows=1,cols=len(head));t.autofit=False
    for i,(txt,w) in enumerate(zip(head,widths)):
        t.columns[i].width=Inches(w);t.rows[0].cells[i].text=txt
    for row in rows:
        for c,txt in zip(t.add_row().cells,row):c.text=txt
    for ri,row in enumerate(t.rows):
        pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        for c,w in zip(row.cells,widths):
            c.width=Inches(w);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            pr=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
            for side in ['top','left','bottom','right']:
                x=OxmlElement('w:'+side);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');b.append(x)
            pr.append(b);mar=OxmlElement('w:tcMar')
            for side in ['top','left','bottom','right']:
                x=OxmlElement('w:'+side);x.set(qn('w:w'),'80');x.set(qn('w:type'),'dxa');mar.append(x)
            pr.append(mar);sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'DCE6EC' if ri==0 else 'FFFFFF');pr.append(sh)
            for q in c.paragraphs:
                q.paragraph_format.space_after=Pt(2);q.paragraph_format.line_spacing=1.02
                for run in q.runs:run.font.size=Pt(9.5);run.bold=ri==0
    t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

doc.add_paragraph('BFG Composition through Neutral Relations','Title')
doc.add_paragraph('Conditional Derivation of the Bell Form and Connection to Level Zero','Subtitle')
p('Prepared for Marcel Theodor Wende · 30 September 2026')
p('Result. The two-dimensional complex BFG carrier supports a joint relation between two systems. Requiring linear closure under independent operations at both endpoints yields a four-dimensional complex relation space. An additional, explicit neutral intertwining condition determines a unique normalized direction up to an overall phase. In aligned pole coordinates, this direction has the Bell form.')
p('The derivation obtains this direction as the solution of a relation equation. A positive semidefinite mismatch operator incorporates the condition into the quartic BFG formation functional. Within an explicitly real relation sector, L0+ selects the direction, and the previously proposed G0 continuation preserves it exactly. The composition rule and matched intertwining are constitutive additions; they are not presented as established consequences of historical Level 0.')
h('1 Sources and status of the assumptions')
table(['Component','Mathematical status'],[
('Local carrier','Complex Hilbert structure, two orthogonal pole representatives, and local operators from the carrier paper [1].'),
('Formation and neutral load','The real quartic functional and explicitly added L0+ rule from [2].'),
('Continuation','The proposed real G0 rule from [3], used without modification.'),
('R1 Relational closure','New rule: a nonzero complex-linear space closed under local operator actions on both sides.'),
('R2 Relation metric','New symmetry assumption: independent unitary endpoint changes preserve the same metric, with no additional endpoint metric.'),
('R3 Neutral intertwining','New source condition: matched local operations agree across a unitary relation T, with isotropic positive mismatch costs.'),
('Measurement statistics','The additional measurement assumptions from [4] remain necessary and are not treated here as BFG consequences.')],[1.55,5.55])
p('The two systems are denoted P₁ and P₂. Each system has two poles; these poles must be distinguished from the two systems themselves. The calculation uses BFG sources and elementary linear algebra. The benchmark [5] provides a check on proof status, rather than an additional physical law. Identifying an action scale S₀ with a measured constant is unnecessary for the relation theorems below.')

page();h('2 Composition from relational closure')
p('The starting point is the pole projectors and the directed relation of the carrier paper [1, equations 10–14]. Their complex algebra contains all four matrix units. We adopt that paper’s matrix representation, including its orthogonal pole basis. Linear independence of two poles alone would not establish this orthogonality.')
eq('local')
p('Rule R1. A joint configuration is represented by a linear relation R from H₂ to H₁. Admissible relations form a nonzero complex subspace preserved by the locally generated operators acting on either side:')
eq('space')
p('Theorem 1. R1 forces the full relation space. Proof. Choose a nonzero relation R₀ and a nonzero entry with indices a,b. For arbitrary i,j,')
eq('units')
p('Every matrix unit Eᵢⱼ therefore belongs to the admissible space. Their four complex coefficients are independent, so the space is precisely M₂(C). This equation proves the closure statement. The identification of joint physical configurations with these relations is the content of the new rule R1.')
p('Theorem 2. R2 determines any positive Hermitian relation metric up to a common scale. Independent phases of the local basis vectors multiply Eᵢⱼ by distinct phase factors. Invariance therefore makes different matrix units orthogonal. Local permutations make their four norms equal. Choosing the common unit gives')
eq('metric')
p('This is the Hilbert–Schmidt metric. R2 is stronger than coordinate covariance: the components of a general metric could transform with the basis. Here, the absence of an additional distinguished endpoint metric is an explicit requirement.')
eq('vec');eq('action')
p('The tensor product thus appears as an algebraic representation of the relation space. The second factor is the conjugate carrier because R acts contravariantly at its second endpoint. The superscript c denotes the conjugate carrier or componentwise conjugation. The transpose in the last equation is essential, particularly for the imaginary relation Y.')

page();h('3 The neutral relation determines the joint direction')
p('Rule R3. For two structurally identical local BFG carriers, specify a unitary identification T between their pole frames. Neutral intertwining means that a local Hermitian operation can be transferred to the corresponding side of the relation without changing the joint configuration:')
eq('match')
p('Theorem 3. Every such relation has the form R = cT. Proof. Set S = T†R. The intertwining equation requires S to commute with all local Hermitian operators. The pole contrast Z and mixing operation X already suffice:')
eq('comm')
p('Normalization from Theorem 2 fixes the magnitude of the sole remaining coefficient. Since T is unitary and two-dimensional, its squared norm is 2. Hence')
eq('neutral');eq('bell')
p('The Bell form therefore follows from neutral intertwining. The factor 1/√2 follows from the relation norm, and equality of the two coefficients follows from the mixing condition involving X. The overall phase leaves the rank-one projector Q_T unchanged.')
eq('reduced')
p('The normalized coefficient operator has rank two and two equal singular values. A product vector would have a coefficient operator of rank one. The joint vector is therefore nonseparable with respect to the endpoint decomposition obtained from R1, and both algebraic reductions are I/2. Interpreting them as local measurement states additionally requires a statistical assignment.')
p('Why both conditions are needed. Intertwining with Z alone allows every diagonal matrix, including the product case diag(1,0). The invertible relation diag(1,2)/√5 also preserves both pole directions, yet has unequal weights 1/5 and 4/5. Nonfragmentation alone therefore does not force the Bell form. The additional intertwining of mixing operations is the decisive requirement.')
p('Choosing T = I aligns the frames; it does not select a physically preferred absolute orientation. Any other unitary T gives the same class of equal singular values. The universal BFG roles do not yet determine T or the realization of R3 in a concrete source.')

page();h('4 A positive neutral operator for the intertwining condition')
p('In the frame T = I, the three local Hermitian directions X, Y, and Z are the matrices already obtained from the BFG poles and conjugate relation. R3 assigns equal weight to their intertwining mismatches. For positive coupling strength g, define the quadratic relation energy by')
eq('axes');eq('cost');eq('load')
p('Proof of the last identity. Every matrix R satisfies Σⱼ σⱼRσⱼ = 2 tr(R)I − R. Substitution into the double commutators gives the stated formula. Left and right multiplication by these Hermitian matrices are self-adjoint in the relation metric, so each squared norm contributes a positive quadratic form.')
eq('ambient')
p('Thus L has exactly one complex zero mode and three positive eigenvalues 4g. Its kernel is the neutral intertwining relation solved above. The Bell vector is not supplied as an independent state input to the cost functional, although its selection is already encoded in the strong intertwining condition.')
p('Conditional uniqueness. Any complex-linear self-adjoint mismatch operator that is invariant under common unitary frame rotations and annihilates the identity relation is scalar on the traceless subspace. In the Pauli basis, 180-degree rotations first force a diagonal form; 90-degree rotations make its three diagonal entries equal. Nondegenerate intertwining requires this scalar to be positive. The form of L is consequently fixed up to g. Without isotropy, unequal positive directional weights remain admissible; the BFG designation “neutral” alone does not fix them.')
eq('frame')
p('The representation is independent of the chosen local frames. In general, the three left and right directions transform with U and V, respectively. The mismatch AⱼR − RBⱼ and its norm then transform consistently, and the kernel becomes the line through UTV†. This covariance prevents an unintended preference for numerical coordinates.')
p('Relation to the earlier model. The earlier real calculation [4] used X and Z. The local BFG algebra derived here also includes Y. Including it with equal weight makes the three transverse loads equal. This changes the declared source coupling while leaving the G0 continuation rule unchanged.')

page();h('5 Formation and the limit of the complex extension')
p('The new relation operator defines a positive capacity family within the BFG formation scheme. The parameter range is specified before selection:')
eq('capacity')
p('For general T, L = 4g(I − Q_T). With r = vec(R), the full complex relation space first gives the following real-valued energy problem:')
eq('quartic');eq('minima')
p('Proof. L is positive semidefinite and vanishes precisely on the neutral line. The scalar function −κr²/2 + r⁴/4 has minimum −κ²/4 at r² = κ. Equality requires both the neutral direction and this radius. All normalized minimizers therefore have the same projector Q_T.')
p('Compatibility with L0+. The integrated L0+ paper [2] states its strict Hessian theorem on a real carrier with a simple ground mode. The complex space instead has a circle of minima. The correct real Hessian at the representative √κ φ_T is')
eq('hessian');eq('hspec')
p('Here P with superscript R projects onto the single real radial direction φ_T. The direction iφ_T is the overall phase and has zero energy curvature at the minimum. The Hessian is therefore singular on the full eight-dimensional real space. Extending the real L0+ formula to this space merely by replacing transposes with adjoints would be incorrect.')
p('A quotient by the overall phase would locally have seven real tangent directions. A fully defined G0 successor on this quotient is absent from the examined sources and is not claimed here. To connect directly to the already verified BFG continuation, the next section selects an explicit four-dimensional real relation sector.')
p('This restriction has a definite mathematical effect. Besides the overall phase direction, it removes the three imaginary traceless directions. It therefore goes beyond fixing the overall phase. The full complex carrier construction and the subsequent real G0 realization have different domains of validity.')

page();h('6 Exact selection and continuation in the real relation sector')
p('On the following real subspace, formation and the positive local Hessian have exactly the form required by the integrated L0+ paper. Although the Pauli matrix Y has imaginary entries, its coefficient in this sector is real:')
eq('section');eq('realH')
p('In other local frames, this sector becomes {UHV† : H = H†}. For T = UV†, this is equivalent to RT† = TR†. The sector choice is therefore well defined when the relation transforms consistently. It does not describe every complex joint state.')
p('Theorem 4. L0+ and the strict G0 selector pick precisely the neutral direction in this sector. Proof. H and N are diagonal in the stated orthonormal basis. The L0+ definition of neutral load yields')
eq('loadY');eq('selector')
p('Because 0 < ν < 2κ, only the first load eigenvalue lies below one. A concrete initially separable relation state is consequently selected and normalized as follows:')
eq('seed')
p('The coefficient vector of R₀ in the basis above determines the two initial G0 densities:')
eq('densities')
p('Theorem 5. The unchanged G0 rule [3] maps this initial state to the embedded neutral rank-one state in one step. Its active capacities and densities are')
eq('fixed')
p('Proof. The selector retains only e₀. The two analysis branches are therefore collinear; their normalized polar embedding compresses each duplicated inherited capacity to its value in this direction. Formation mass becomes κ, and the normalized witness becomes 1. In the active scalar space, K₊ = −κ and H₊ = 2κ. All quantities consequently remain unchanged under every further G0 application. Induction proves persistence for arbitrarily many steps.')
p('This is selection followed by normalized continuation, rather than a norm-preserving gate for all inputs. Without a measurement assignment, the retained witness mass 1/2 is not a success probability. Traceless inputs do not survive this selection. A general attractor that corrects arbitrary mass errors is also not established.')

page();h('7 Connection to the measurement model')
p('The composition calculation determines a joint carrier, a neutral direction, and an admissible real preparation. Local operators are evaluated on the embedded relation space. The active G0 scalar alone cannot represent the local algebras. For XZ measurements, the resulting input is the same real Bell vector as in [4]; registration need not remain within the Hermitian relation sector.')
eq('corr');eq('M')
p('Initially, this expression is a normalized quadratic relation quantity. In the real XZ sector, direct evaluation of the trace gives the cosine of the angle difference. At the four previously used settings,')
eq('chsh')
p('Here S_geom denotes C₀₀ + C₀₁ + C₁₀ − C₁₁ for these four geometric values. An experimental CHSH violation additionally requires C to describe correlations of counted individual outcomes. The relation algebra alone does not supply that interpretation.')
eq('bornbridge')
p('The earlier measurement model [4] adds two requirements: the probability of an ideal channel depends only on its normalized mass, and a lossless split into orthogonal subchannels preserves the summed probability. Together with normalization and nonnegativity, rational refinement and monotonicity then force p = w. The present composition does not independently establish these statistical requirements.')
p('Why the distinction remains necessary. The same branch masses also permit the initial definition pⱼ = wⱼ² / Σₖwₖ². For two half-weights, the first probability is 1/2. Splitting that first half-weight into two quarter-weights reduces its combined probability to 1/3. The additional refinement requirement excludes this assignment; the relation space alone contains no such requirement.')
p('The second carrier copy remains conjugated. In standard coordinates, the resulting vector has correlations (+1, −1, +1) for X⊗X, Y⊗Y, and Z⊗Z. Transferring the original operator Y at the second endpoint introduces Yᵀ = −Y through conjugation. The positive sign in the original intertwining condition is therefore consistent with the negative Y⊗Y correlation.')
p('A fully BFG-internal event theory still requires a concrete registration process, its probability assignment, and an account of the occurrence of an individual outcome. The scale S₀ in the carrier paper connects energy and phase; this relation alone does not determine counting statistics. The relation construction proved here provides a more precise starting point for that further step.')

page();h('8 Computational verification and sources')
p('The proofs were checked using exact matrix identities and numerical variants. Matrix units, the load formula, and kernel dimensions are checked with small exactly representable Gaussian integers or rational row reduction. The claims for arbitrary positive parameters follow from the proofs above; the samples provide an independent computational cross-check.')
table(['Check','Result'],[
('Sources and local frames','96 variants with different κ, ν, g and independently varied unitary endpoint frames.'),
('Unchanged G0 continuation','Five steps per variant, 480 successful continuations in total; direction and formation mass agree with the fixed-point theorem.'),
('Largest numerical residual',f"{results['max_residual']:.3g}; all prescribed tolerances met."),
('Real example κ = 2, ν = 1, g = 1','H = diag(4,4,4,4); Y_N = diag(1/16,25/16,25/16,25/16).'),
('Full complex space check','The full real Hessian has rank seven; the overall phase remains a zero direction.'),
('Removal of mixing','Intertwining with Z alone leaves a two-dimensional kernel and admits the product case diag(1,0).'),
('Geometric correlation combination','2.8284271247461903; its interpretation as counted CHSH statistics remains conditional on measurement assumptions.')],[2.1,5.0])
p('The reproducibility package contains the complete verification script, results, unchanged G0 source, and document generator. It uses Python '+results['environment']['python']+' and NumPy '+results['environment']['numpy']+'. No experimental data were analyzed. The numerical results check the mathematics and do not confirm a physical realization.')
p('Established scope. Under R1–R3, the shared Bell-form balance is mathematically determined. The real L0+ and G0 connection is fully worked out. Deriving the complex Hilbert structure from a more primitive Level 0, defining a general complex continuation, and independently establishing event statistics remain separate tasks. Calling the additional rules a BFG extension does not make them theorems of the historical core.')
p('References',True)
refs=[
'[1] Marcel Theodor Wende. Minimal Carrier and Action-Scale Closure in the Balance–Field Framework. 22 September 2026. Especially Sections 2–8 and Appendix A.',
'[2] Marcel Theodor Wende. BFG Neutral First Reclosure and the Conditions for Emergence. Integrated preprint with amended Level 0, revised 30 September 2026. Especially Section 2.',
'[3] BFG G0 as a New Continuation Axiom. Justification and Mathematical Consequences of a Revised Neutral Feedback Rule. Prepared for Marcel Theodor Wende, 30 September 2026; with Closed BFG Dynamics with Separate Neutral Load and the unchanged module g0_model.py. Manuscript titles translated from German.',
'[4] BFG Measurement Model with Neutral Continuation. Balance Coupling, Local Registration, and Conditional Outcome Probabilities. Prepared for Marcel Theodor Wende, 30 September 2026. Especially Sections 2, 4, and 5. Manuscript title translated from German.',
'[5] Marcel Theodor Wende. BFG Natural-Emergence Benchmark and Capacity-Matched Null-Model Tournament. 9 September 2026. Quantum Mechanics section; a historical assessment, not an evaluation of later additions.'
]
for txt in refs:
    q=p(txt)
    for run in q.runs:run.font.size=Pt(9)
doc.save(OUT/'BFG_Relational_Composition_and_Balance_State_2026-09-30.docx')
print(json.dumps({'document':str(OUT/'BFG_Relational_Composition_and_Balance_State_2026-09-30.docx'), 'equations':counter},indent=2))
