"""Proposed G0 closure on the full-persistence real finite sector.

G0 is a new, explicit replacement of the feedback role of the old Gram rule.
It is not represented as a theorem forced by the historical BFG axioms.
The Gram matrix is returned as a diagnostic; neutral load is always derived
from the current capacities. No probabilities are part of this model.
"""
from dataclasses import dataclass
import numpy as np

def sym(a): return (a+a.T)/2
def norm(a): return float(np.linalg.norm(a,2))

class Gate(Exception):
    def __init__(self,status,reason):self.status=status;self.reason=reason

@dataclass
class State:
    C: np.ndarray
    N: np.ndarray
    D: np.ndarray
    F: np.ndarray
    W: np.ndarray
    embedding: np.ndarray
    @property
    def K(self):return sym(self.C+self.N-self.D)
    @property
    def dim(self):return self.N.shape[0]

def neutral(K,N,tol=1e-11):
    lam,U=np.linalg.eigh(sym(K))
    if lam[0]>tol:raise Gate('terminal','no_negative_formed_ground')
    if abs(lam[0])<=tol:raise Gate('numerically_unresolved','ground_sign_boundary')
    if len(lam)>1 and lam[1]-lam[0]<=tol:
        raise Gate('numerically_unresolved','ground_gap_unresolved_or_degenerate')
    q=np.outer(U[:,0],U[:,0])
    H=sym(K-lam[0]*np.eye(len(K))-2*lam[0]*q)
    h,V=np.linalg.eigh(H)
    if h[0]<=tol:raise Gate('numerically_unresolved','hessian_not_resolved_positive')
    inv=(V*(1/np.sqrt(h)))@V.T
    A=sym(inv@N@inv);Y=sym(A@A)
    return Y,H,float(lam[0]),q

def validate(s,tol=1e-11):
    n=s.dim
    for name in ['C','N','D','F','W']:
        a=getattr(s,name)
        if a.shape!=(n,n) or not np.isfinite(a).all() or np.iscomplexobj(a):raise Gate('invalid_input',name+'_shape_reality_or_finiteness')
        if norm(a-a.T)>tol:raise Gate('invalid_input',name+'_not_symmetric')
        v=np.linalg.eigvalsh(a)
        if v[0]<-tol:raise Gate('invalid_input',name+'_not_positive_semidefinite')
        if name=='N' and v[0]<=tol:raise Gate('numerically_unresolved','neutral_capacity_not_resolved_positive')
    if np.trace(s.F)<=tol:raise Gate('numerically_unresolved','formation_mass_unresolved_or_zero')
    if abs(np.trace(s.W)-1)>tol:raise Gate('invalid_input','witness_not_normalized')
    if s.embedding.ndim!=2 or s.embedding.shape[1]!=n or not np.isfinite(s.embedding).all() or np.iscomplexobj(s.embedding) or norm(s.embedding.T@s.embedding-np.eye(n))>100*tol:
        raise Gate('invalid_input','embedding_not_isometric')

def step(s,tol=1e-11):
    """One autonomous G0 step; failures have explicit statuses, never a fake state."""
    try:
        validate(s,tol)
        Y,H,lam,q=neutral(s.K,s.N,tol)
        yy,v=np.linalg.eigh(Y)
        if np.min(np.abs(yy-1))<=100*tol:
            raise Gate('numerically_unresolved','neutral_selection_boundary')
        z=v[:,yy<1]
        if z.shape[1]==0:raise Gate('terminal','no_closure_positive_sector')
        Q=sym(z@z.T)
        m=float(np.trace(Q@s.W))
        if m<=tol:raise Gate('numerically_unresolved','witness_survival_unresolved_or_zero')
        fs=sym(Q@s.F@Q); ws=sym(Q@s.W@Q)/m
        if np.trace(fs)<=tol:raise Gate('numerically_unresolved','selected_formation_unresolved_or_zero')
        I=np.eye(s.dim);c=np.linalg.inv(I+Y);b=Y@c;metric=I+Y
        lc=float(np.trace(metric@Q@c@fs@c@Q));lb=float(np.trace(metric@Q@b@fs@b@Q))
        if min(lc,lb)<=tol:raise Gate('numerically_unresolved','branch_load_not_resolved_positive')
        alpha=lb/(lc+lb)
        A=np.vstack([np.sqrt(alpha)*Q@c,np.sqrt(1-alpha)*Q@b])
        u,sing,vh=np.linalg.svd(A,full_matrices=False)
        r=int(np.count_nonzero(sing>tol))
        if r!=z.shape[1]:raise Gate('numerically_unresolved','analysis_rank_unresolved')
        u=u[:,:r];V=vh[:r,:].T
        # Fix the arbitrary SVD column signs; only physical lifts are compared.
        for j in range(r):
            if V[np.argmax(np.abs(V[:,j])),j]<0:V[:,j]*=-1;u[:,j]*=-1
        def cap(a):return sym(u.T@np.kron(np.eye(2),a)@u)
        nxt=State(cap(s.C),cap(s.N),cap(s.D),sym(V.T@fs@V),
                  sym(V.T@ws@V),s.embedding@V)
        nxt.W/=np.trace(nxt.W)
        validate(nxt,tol)
        Yplus,Hp,lp,qp=neutral(nxt.K,nxt.N,tol)
        gram=np.diag(sing[:r]**2)
        return dict(status='success',state=nxt,neutral_before=Y,neutral_after=Yplus,
                    gram=gram,selector=Q,retained_mass=m,alpha=alpha,
                    lambda_c=lc,lambda_b=lb,recursion=np.eye(r),
                    minimum_before=lam,minimum_after=lp)
    except Gate as e:return dict(status=e.status,reason=e.reason,state=None)

def lift(s,which='W'):
    return sym(s.embedding@getattr(s,which)@s.embedding.T)

def family(kappa=2.,nu=1.,gx=1.,gz=1.5):
    I=np.eye(4);X=np.array([[0.,1.],[1.,0.]]);Z=np.diag([1.,-1.])
    N=nu*I+gx*(I-np.kron(X,X))+gz*(I-np.kron(Z,Z))
    rho=np.outer(I[:,0],I[:,0])
    return State(np.zeros((4,4)),N,(nu+kappa)*I,2*kappa*rho,rho,I)

def stability_certificate(eps_k=.005,eps_n=.005):
    """Proved sufficient bounds around kappa=2, nu=1, gx=1, gz=1.5."""
    if not (0<=eps_k<2):raise ValueError('K perturbation must be below the nominal spectral gap')
    s_k=eps_k/(2-eps_k)
    e_h=4*eps_k+4*s_k;h_lower=2-e_h
    if h_lower<=0:raise ValueError('this sufficient bound does not resolve H positivity')
    l=e_h/(2*h_lower**1.5)
    w0=1/np.sqrt(2);w1=1/np.sqrt(h_lower)
    e_a=l*(6+eps_n)*w1+w0*eps_n*w1+w0*6*l
    e_y=e_a*(3+e_a)
    gap=1.44-.0625
    if e_y>=min(.44,gap):raise ValueError('this sufficient bound does not resolve selector rank')
    d=e_y/(gap-e_y)
    k_upper=-2+5*d*d+eps_k;n_upper=1+5*d*d+eps_n
    if k_upper>=0 or n_upper>=-2*k_upper:raise ValueError('this sufficient bound does not close the successor')
    return dict(eps_K=eps_k,eps_N=eps_n,ground_projector_bound=s_k,
       H_difference_bound=e_h,H_min_lower=h_lower,inverse_sqrt_difference_bound=l,
       A_difference_bound=e_a,Y_difference_bound=e_y,selector_projector_bound=d,
       fidelity_lower=1-d*d,overlap_lower=.5-d,K_target_upper=k_upper,
       N_target_upper=n_upper,Y_target_upper=(n_upper/(-2*k_upper))**2,
       conditional_fixed_settings_CHSH_lower=2*np.sqrt(2)*(1-2*d*d))
