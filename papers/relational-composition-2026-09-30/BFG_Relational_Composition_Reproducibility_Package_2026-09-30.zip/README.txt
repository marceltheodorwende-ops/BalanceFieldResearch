BFG Relational Composition and Balance State
30 September 2026

This package verifies an explicitly proposed BFG extension. The accompanying
paper declares the additional rules R1 (relational closure), R2 (relation
metric), and R3 (neutral intertwining). They are not presented as established
consequences of historical Level 0. No HLV, Spiral-Time, or SIEL assumptions
are used.

Run the mathematical verification
    python3 verify_relational.py

Verification dependencies
    Python 3.12 or compatible; NumPy
    Standard-library fractions for exact rational row reduction

The verification writes results.json. It uses 96 source variants and five
G0 continuation steps per variant, with seed 300920264. These are synthetic
computational checks; no individual experimental events are simulated.

source/g0_model.py is byte-identical to the existing real G0 module.
SHA256 c87a313ac59140afa55ce8fa5e11d1f80583747c5200804dbe85e6377aeb4929

The complex relation space is constructed algebraically. G0 operates only
on its explicit real Hermitian sector. At the quartic minimum, the full
complex space has a real phase zero mode. A positive Hessian on that full
space is explicitly not claimed.

The reported geometric CHSH combination is not measurement statistics
independently derived from G0. The earlier report's measurement assumptions
remain additional requirements.

Generate the English paper with native editable Word equations
    python3 build_report.py

Additional builder dependencies: python-docx, lxml, and Pandoc.
The builder reads results.json and generates the equations and DOCX.
Output: deliverables/BFG_Relational_Composition_and_Balance_State_2026-09-30.docx

The English publication preserves the original mathematical results,
verification script, and G0 implementation. Its rendered pages were visually
checked before publication. Running the builder alone does not perform
that visual review.
