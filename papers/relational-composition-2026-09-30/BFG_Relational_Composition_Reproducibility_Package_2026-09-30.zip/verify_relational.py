"""Finite checks for the explicitly proposed BFG relational composition branch.

No measurement probabilities or random experimental outcomes are assumed here.
The unchanged G0 routine acts only on the real Hermitian relation section.
"""
from pathlib import Path
import hashlib, json, platform, sys
from fractions import Fraction
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))
from g0_model import State, step, lift

I = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.diag([1., -1.]).astype(complex)
SIGMA = (X, Y, Z)
HB = tuple(a / np.sqrt(2) for a in (I, X, Y, Z))

def vec(r):
    """Row-order vectorization: vec(A R B) = (A tensor B.T) vec(R)."""
    return np.asarray(r).reshape(-1)

def supermatrix(fn):
    standard = np.eye(4, dtype=complex)
    return np.column_stack([vec(fn(v.reshape(2, 2))) for v in standard])

def hs(a, b):
    return np.vdot(a, b)

def unitary(rng):
    a = rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2))
    q, r = np.linalg.qr(a)
    d = np.diag(r)
    return q @ np.diag(d / np.abs(d))

def relation_load(a_axes, b_axes, g):
    defects = [np.kron(a, I) - np.kron(I, b.T)
               for a, b in zip(a_axes, b_axes)]
    return g / 2 * sum(d.conj().T @ d for d in defects)

residuals = {}
def check(key, value, tolerance=2e-10):
    value = float(np.linalg.norm(value))
    residuals[key] = max(residuals.get(key, 0.), value)
    assert value < tolerance, (key, value, tolerance)

def exact_checks():
    # Every entry and intermediate here is a small Gaussian integer or half
    # integer, exactly representable in binary. No eigenvalue tolerance is used.
    ds = [np.kron(s,I)-np.kron(I,s.T) for s in SIGMA]
    ell = sum(d.conj().T@d/2 for d in ds)
    v = np.array([1,0,0,1])
    q = np.outer(v,v)/2
    assert np.array_equal(ell, 4*(np.eye(4)-q))
    basis = np.column_stack([vec(a) for a in (I,X,Y,Z)])
    assert np.array_equal(basis.conj().T@basis, 2*np.eye(4))
    assert np.array_equal(basis.conj().T@ell@basis, np.diag([0,8,8,8]))
    def exact_rank(a):
        rows = [[Fraction(int(x)) for x in row] for row in a]
        pivot = 0
        for j in range(len(rows[0])):
            k = next((k for k in range(pivot,len(rows)) if rows[k][j]), None)
            if k is None: continue
            rows[pivot],rows[k] = rows[k],rows[pivot]
            d = rows[pivot][j]
            rows[pivot] = [x/d for x in rows[pivot]]
            for k in range(len(rows)):
                if k != pivot:
                    d = rows[k][j]
                    rows[k] = [x-d*y for x,y in zip(rows[k],rows[pivot])]
            pivot += 1
        return pivot
    # The Y defect is purely imaginary; divide its equations by i.
    assert exact_rank(np.vstack([ds[0].real,ds[1].imag,ds[2].real])) == 3
    assert exact_rank(ds[2].real) == 2
    # Positive symbolic parameters give the same rank by the printed diagonal
    # formula in the proof; this checks the exact kappa=2, g=1 representative.
    h8 = np.diag([4,4,4,4,0,4,4,4])
    assert exact_rank(h8) == 7
    yn = [Fraction(1,16)] + [Fraction(25,16)]*3
    return {'commutator_load_identity': True,
            'joint_kernel_dimension_complex': 1,
            'single_pole_axis_kernel_dimension_complex': 2,
            'real_full_hessian_rank': 7,
            'complex_phase_hessian_zero_mode': True,
            'base_Y_eigenvalues': [str(v) for v in yn]}

def main():
    seed = 300920264
    rng = np.random.default_rng(seed)
    E = np.column_stack([vec(h) for h in HB])
    e0 = np.eye(4)[:, 0]
    qc = np.outer(e0, e0)
    phi = vec(I) / np.sqrt(2)
    qphi = np.outer(phi, phi.conj())
    exact = exact_checks()
    count = 96
    for _ in range(count):
        u, v = unitary(rng), unitary(rng)
        t = u @ v.conj().T
        a_axes = [u @ s @ u.conj().T for s in SIGMA]
        b_axes = [v @ s @ v.conj().T for s in SIGMA]
        kappa = float(rng.uniform(.8, 3.5))
        nu = float(rng.uniform(.15, 1.65) * kappa)
        g = float(rng.uniform(.3, 3.))
        ell = relation_load(a_axes, b_axes, g)
        qt = np.outer(vec(t), vec(t).conj()) / 2
        check('load_identity', ell - 4*g*(np.eye(4)-qt))
        check('kernel_T', ell @ vec(t))
        check('singular_values_T', np.linalg.svd(t/np.sqrt(2), compute_uv=False)
              - np.ones(2)/np.sqrt(2))
        check('left_reduction', t@t.conj().T/2-I/2)
        check('right_reduction', (t.conj().T@t).T/2-I/2)

        r = rng.normal(size=(2,2)) + 1j*rng.normal(size=(2,2))
        # Matrix-unit generation of every relation from any nonzero seed.
        ai, bj = np.unravel_index(np.argmax(np.abs(r)), r.shape)
        for i in range(2):
            for j in range(2):
                left, right, target = np.zeros((3,2,2), dtype=complex)
                left[i, ai] = 1
                right[bj, j] = 1
                target[i, j] = 1
                check('matrix_unit_generation', left@r@right/r[ai,bj]-target)
        aa = a_axes[0] + .37*a_axes[1]
        bb = b_axes[1] - .19*b_axes[2]
        check('vectorization', vec(aa@r@bb)-np.kron(aa, bb.T)@vec(r))
        check('endpoint_commutation', aa@(r@bb)-(aa@r)@bb)
        basis = np.column_stack([vec(u@h@v.conj().T) for h in HB])
        check('moving_frame_isometry', basis.conj().T@basis-np.eye(4))
        check('real_section_load', basis.conj().T@ell@basis
              - np.diag([0,4*g,4*g,4*g]))

        # Exact real sector, no alteration of G0 to pretend complex support.
        lc = np.diag([0., 4*g, 4*g, 4*g])
        source_vector = np.array([1.,0,0,1.])/np.sqrt(2)
        rho = np.outer(source_vector, source_vector)
        s = State(np.zeros((4,4)), nu*np.eye(4)+lc,
                  (nu+kappa)*np.eye(4), 2*kappa*rho, rho, np.eye(4))
        expected_neutral = np.diag([(nu/(2*kappa))**2]
                                   +[(1+nu/(4*g))**2]*3)
        for n in range(5):
            result = step(s)
            assert result['status'] == 'success', result
            if n == 0:
                check('source_Y', result['neutral_before']-expected_neutral)
                check('retained_witness', result['retained_mass']-.5)
                check('selector', result['selector']-qc)
            s = result['state']
            check('fixed_point_density', lift(s)-qc)
            check('formation_mass', np.trace(s.F)-kappa)
            check('neutral_persistence', result['neutral_after']
                  -np.array([[(nu/(2*kappa))**2]]))
            check('embedded_density', basis@lift(s)@basis.conj().T-qt)

        # The full real Hessian on the complex relation carrier.
        h8 = np.diag([2*kappa,4*g,4*g,4*g,0,4*g,4*g,4*g])
        check('global_phase_zero_mode', h8@np.eye(8)[:,4])
        x = rng.normal(size=8)
        cc = x[:4] + 1j*x[4:]
        d = E@cc
        curvature = np.vdot(d, (4*g*(np.eye(4)-qphi))@d).real
        curvature += 2*kappa*(np.vdot(phi,d).real)**2
        check('real_hessian_quadratic_form', x@h8@x-curvature)

    # A removal control: without the mixing quadrature, product P_+ survives.
    product = np.diag([1., 0.]).astype(complex)
    assert np.linalg.matrix_rank(product) == 1
    check('single_axis_product_null', Z@product-product@Z)
    check('full_balance_product_defect', sum(np.linalg.norm(s@product-product@s)**2
                                           for s in SIGMA)-4.)
    # A nonzero full-rank relation need not be balanced or maximally entangled.
    unbalanced = np.diag([1., 2.])/np.sqrt(5)
    check('nonfragmentation_is_not_balance',
          np.diag(unbalanced.T@unbalanced)-np.array([.2,.8]))

    # A geometric quadratic functional, explicitly not a frequency prediction.
    def m(a): return np.cos(a)*Z+np.sin(a)*X
    def correlation(a,b): return float((np.trace(m(a)@m(b).T)/2).real)
    aa, bb = (0,np.pi/2), (np.pi/4,-np.pi/4)
    cs = [correlation(a,b) for a in aa for b in bb]
    S = cs[0]+cs[1]+cs[2]-cs[3]
    check('geometric_CHSH', S-2*np.sqrt(2))
    full_axes = [[float(np.trace(a@b.T).real/2) for b in SIGMA] for a in SIGMA]
    check('dual_transpose_sign', np.array(full_axes)-np.diag([1.,-1.,1.]))
    # Concrete underdetermination of the statistical rule already shown in M1/M2.
    w = np.array([.5,.5]); split = np.array([.25,.25,.5])
    refinement_alt = [(w*w/np.sum(w*w))[0],
                      np.sum((split*split/np.sum(split*split))[:2])]
    result = {
        'status':'all_checks_passed','seed':seed,'source_instances':count,
        'G0_steps_per_instance':5,'G0_steps_total':count*5,
        'exact':exact,'max_residual':max(residuals.values()),
        'residuals':residuals,'geometric_CHSH':S,
        'CHSH_status':'quadratic_geometry_only_unless_measurement_axioms_added',
        'axis_correlation_matrix':full_axes,
        'alternative_refinement_weights':refinement_alt,
        'base_example':{'kappa':2.,'nu':1.,'g':1.,
                        'H_real_section':[4.,4.,4.,4.],
                        'Y_real_section':[.0625,1.5625,1.5625,1.5625],
                        'retained_witness_mass':.5,'target_formation_mass':2.,
                        'H_full_complex_as_real':[4.,4.,4.,4.,0.,4.,4.,4.]},
        'g0_sha256':hashlib.sha256((ROOT/'source/g0_model.py').read_bytes()).hexdigest(),
        'environment':{'python':platform.python_version(), 'numpy':np.__version__},
        'scope':'BFG-internal proposed relational constitutive extension; real G0 sector; no empirical data'
    }
    (ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','source_instances','G0_steps_total',
                     'max_residual','geometric_CHSH','g0_sha256']},indent=2))

if __name__ == '__main__':
    main()
