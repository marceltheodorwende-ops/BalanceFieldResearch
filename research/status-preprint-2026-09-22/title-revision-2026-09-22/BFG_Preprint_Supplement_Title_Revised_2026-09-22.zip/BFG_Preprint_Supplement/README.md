# Supplement to the BFG status preprint

Marcel Theodor Wende. The Balance Field Framework. Mathematical Foundations, Conditional Closure, and the Path to Empirical Validation. Version 1, 21 September 2026.

## Reproduction

Use Python 3.12 and a virtual environment. From this folder run:

```text
python -m pip install -r requirements.txt
python rlc/analyze.py
python reproduce_figures.py
```

The first script fits the conventional RLC circuit from the included measured spectrum. The second regenerates all four figures and the deterministic finite-model data. No random numbers are used. PNGs are publication figures; SVGs are vector versions. Figure 4 evaluates the fitted circuit on 1,800 plotting frequencies and retains all 81 measured data points.

## Data and provenance

Figures 1–3 and simulation_data are new synthetic model calculations, not physical observations. Figure 4 uses data from Michael A. Danzer, Christian Plank and Tom Rüther, *Impedance data for various electrochemical and electrical systems*, version 1.0.0 (2024), https://doi.org/10.5281/zenodo.10794584. The RLC dataset is licensed CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. The measured file is unchanged; the circuit fit and visualization are analyses of that file. See rlc/SOURCE.json for source metadata and RUN_MANIFEST.json for its SHA256 checksum. No author-generated empirical measurements are claimed.

The historical_source_manifest.json preserves the original provenance audit, dated 18 September, including its historical repository commit. The manuscript uses the later computational baseline e6670bc4a662ffdcb0d54345b6fbbc02be327f1e. These dates/commits are deliberately distinct. The source manifest covers five foundational manuscripts and the three audit-method documents; those historical documents are not rewritten or redistributed in this archive.

The equation/figure/table/reference index is in manuscript_index.json. The finite SA reference implementation and tests remain in the source repository at https://github.com/marceltheodorwende-ops/BalanceFieldResearch/tree/e6670bc4a662ffdcb0d54345b6fbbc02be327f1e . Fourteen focused CTC-SA tests passed during manuscript preparation; this is software verification, not empirical validation.

## Interpretation

The manuscript reports conditional finite closure, explicit counterexamples and unresolved extensions. The ordinary RLC fit is not evidence for a BFG-specific transition law. All seven universal closure questions remain subject to the qualifications in the paper.

SHA256SUMS.txt covers all files in this archive except itself.

## Manuscript reproduction

Run `python build_manuscript.py` to regenerate the DOCX using the included equation PNGs. Display equations are high-resolution MathJax 3.2.2 images because the Word/LibreOffice OMML conversion dropped symbols. Editable LaTeX source for all equations is in manuscript_index.json; vector SVG counterparts are in equations/. The displayed mathematical content was checked in all 19 rendered pages. The manuscript date remains 21 September 2026; final layout verification and publication preparation completed 22 September 2026.

Title revision dated 22 September 2026: title, subtitle and running header updated; mathematical body and results unchanged.
