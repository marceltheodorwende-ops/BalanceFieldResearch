import sys,re,json,shutil,zipfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent

from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree


OUT=ROOT;FIG=OUT/'figures'
doc=Document();sec=doc.sections[0]
sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
sec.top_margin=Inches(.78);sec.bottom_margin=Inches(.72)
sec.left_margin=sec.right_margin=Inches(.86)
sec.header_distance=sec.footer_distance=Inches(.3)
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
 st=doc.styles[name];st.font.name='Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
st=doc.styles['Normal'];st.font.size=Pt(11);st.paragraph_format.line_spacing=1.08;st.paragraph_format.space_after=Pt(6)
for name,size in [('Title',23),('Subtitle',13),('Heading 1',15),('Heading 2',12),('Caption',9.5)]:
 doc.styles[name].font.size=Pt(size)
doc.styles['Heading 1'].paragraph_format.space_after=Pt(10)
doc.styles['Heading 2'].paragraph_format.space_before=Pt(8)
doc.styles['Caption'].paragraph_format.line_spacing=1.03
doc.core_properties.author='Marcel Theodor Wende'
doc.core_properties.title='The Balance Field Framework'
doc.core_properties.subject='BFG research status and reproducible finite models as of 21 September 2026'
doc.core_properties.keywords='BFG, Gram reconstruction, persistence, conditional closure, identifiability, RLC'
header=sec.header.paragraphs[0];header.text='BFG   |   Mathematical foundations and empirical validation   |   Preprint v1'
header.runs[0].font.size=Pt(8)
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
rr=footer.add_run();fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');rr._r.addnext(fld)
eqs=[];figs=[];tables=[]

def p(text,style=None):
 x=doc.add_paragraph(text,style);x.paragraph_format.widow_control=True;return x
def head(text):doc.add_paragraph(text,'Heading 1')
def sub(text):doc.add_paragraph(text,'Heading 2')
def page(title):doc.add_page_break();head(title)
def eq(latex,label):
 n=len(eqs)+1
 para=doc.add_paragraph();para.paragraph_format.space_before=Pt(4);para.paragraph_format.space_after=Pt(8)
 para.paragraph_format.keep_together=True
 para.paragraph_format.tab_stops.add_tab_stop(Inches(5.95),WD_ALIGN_PARAGRAPH.RIGHT)
 dims=json.loads((OUT/'equations/dimensions.json').read_text())
 para.add_run().add_picture(str(OUT/'equations'/f'eq-{n}.png'),width=Inches(dims[str(n)]))
 para.add_run('\t('+str(n)+')').font.size=Pt(10)
 eqs.append({'number':n,'label':label,'latex':latex});return n
def figure(name,caption):
 n=len(figs)+1
 x=doc.add_paragraph();x.paragraph_format.keep_with_next=True
 x.add_run().add_picture(str(FIG/(name+'.png')),width=Inches(6.35))
 p('Figure '+str(n)+'. '+caption,'Caption');figs.append({'number':n,'file':name,'caption':caption})
def table(headers,rows,widths,caption):
 n=len(tables)+1;p('Table '+str(n)+'. '+caption,'Caption')
 t=doc.add_table(rows=1,cols=len(headers));t.autofit=False
 for i,w in enumerate(widths):t.columns[i].width=Inches(w)
 for i,h in enumerate(headers):t.rows[0].cells[i].text=h
 repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
 for row in rows:
  cells=t.add_row().cells
  for i,value in enumerate(row):cells[i].text=str(value)
 for ri,row in enumerate(t.rows):
  trpr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
  for i,cell in enumerate(row.cells):
   cell.width=Inches(widths[i]);pr=cell._tc.get_or_add_tcPr()
   borders=OxmlElement('w:tcBorders')
   for side in ['top','left','bottom','right']:
    b=OxmlElement('w:'+side);b.set(qn('w:val'),'single');b.set(qn('w:sz'),'4');b.set(qn('w:color'),'D9D9D9');borders.append(b)
   pr.append(borders)
   margins=OxmlElement('w:tcMar')
   for side in ['top','left','bottom','right']:
    z=OxmlElement('w:'+side);z.set(qn('w:w'),'70');z.set(qn('w:type'),'dxa');margins.append(z)
   pr.append(margins)
   if ri==0:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E8EDF2');pr.append(sh)
   for para in cell.paragraphs:
    para.paragraph_format.space_after=Pt(2);para.paragraph_format.line_spacing=1.02
    for run in para.runs:run.font.size=Pt(9);run.bold=(ri==0)
 tables.append({'number':n,'caption':caption})

doc.add_paragraph('The Balance Field Framework','Title')
doc.add_paragraph('Mathematical Foundations, Conditional Closure, and the Path to Empirical Validation','Subtitle')
p('Marcel Theodor Wende').runs[0].bold=True
p('Balance Field Framework Research\nIndependent Researcher\nORCID 0009-0007-4028-2208\nCorrespondence: marcel-wende@gmx.net')
p('Version 1   |   21 September 2026   |   Preprint, not peer reviewed')
sub('Abstract')
p('The Balance Field Framework (BFG) proposes a common architecture of formation, positive Gram geometry, neutral resolution, persistence and recursive reclosure. This paper establishes a bounded account of its present mathematical and empirical status. We give a complete finite self-adjoint model with explicit state variables and a terminating update, prove its closure under declared assumptions, and derive a structural-energy contraction bound. We correct a persistence definition whose span construction also admits stable directions, distinguish spectral from metric projection, and characterize limitations of Gram inheritance. Constructive alternatives show that four selected rules are not uniquely implied by the examined structural conditions. A packet-collision example proves that the selected next-load rule cannot be reconstructed from the packet alone; in the scalar model, the old squared norm supplies sufficient additional information. We report a deterministic 12,221-point parameter sweep, three finite trajectories and four three-dimensional figures. An exploratory analysis of 81 independently collected RLC impedance measurements obtains a 1.596% relative complex RMS error on interleaved control frequencies using ordinary circuit theory. However, the corresponding autonomous circuit has no peripheral persistent subspace and does not furnish the required BFG transition data. The results strengthen reproducibility and clarify conditional mathematics without establishing universal closure, a unique internal load law, or empirical confirmation of BFG.')
p('Keywords: Balance Field Framework; Gram reconstruction; spectral persistence; conditional closure; identifiability; neutral response; impedance spectroscopy.')
p('Scope statement. Mathematical results below apply only under their stated assumptions. Synthetic trajectories are distinguished from measured impedance data. The external measurements are credited to their collectors, not presented as measurements made by the author.')

page('1 Introduction and evidence standard')
p('The foundational BFG manuscripts develop a sequence from admissible formation to a positive master load, complementary neutral responses, persistence and reclosure [1–5]. Their strongest claims concern a universal iteration that regenerates its own structural data. A compact formula, however, is an executable state law only after the state space, reconstruction functionals, transport rules and domains have been specified. This paper examines that distinction and states the results that currently survive explicit counterexamples.')
p('The audit method uses three author-supplied documents [6–8]. Their operative requirements are claim-state separation, distinguishability, avoidance of mere redescription, source provenance and preservation of negative findings. These are methodological criteria, not additional mathematical axioms. Repository stages retain earlier source documents and subsequent corrections separately [9]. The computational baseline for this preprint is commit e6670bc4a662ffdcb0d54345b6fbbc02be327f1e; the new figure calculations are supplied as supplementary material.')
p('Four levels of evidence are kept distinct. A definition selects a model. A conditional theorem proves a consequence of specified premises. A computational check tests an implementation or an example. An empirical test requires independently acquired observations and a prospectively fixed map from observations to mathematical objects. Agreement at one level does not automatically establish a claim at another. In particular, the number of passing software tests is not a measure of natural universality.')
p('The contribution is a self-contained account of a finite completion, its proofs, its nonuniqueness and the current barriers to physical interpretation. Earlier studies may contain broader terminology; the claims made here are limited by the displayed assumptions and evidence. No priority claim is made for the underlying linear algebra, spectral calculus, rational certification or circuit theory.')
table(['Symbol','Meaning'],[
 ('H, d','Finite complex Hilbert space and its dimension'),('D','Active vector; distinct from the difference capacity'),('Dcap, c, aleph','Difference, coherence and neutral capacities'),('Kf','Formation operator c + aleph − Dcap'),('Y, G','Positive master load and graph metric I + Y'),('R, Psp, PG','Recursion operator, spectral projector, metric projector'),('p, J, E','Cross-fed packet, polar partial isometry, range projector'),('eta, q, g','Current scalar load, packet gain, next scalar load')],[1.35,4.95],'Notation used consistently throughout the paper. The symbol Kf is reserved for formation and is not a Gram factor.')

page('2 Neutral geometry and formation')
p('Let A map a difference channel into a neutral channel. In finite dimension, the nonnegative master load and the exact neutral pair are [1–5]')
eq(r"Y=A^{\dagger}A\succeq0,\qquad G=I+Y\succ0","gram_core")
eq(r"C_N(Y)=(I+Y)^{-1},\quad B_N(Y)=Y(I+Y)^{-1}=I-C_N(Y)","neutral")
p('These operators are positive commuting contractions, with C_N strictly positive. The quadratic neutral functional gives a useful derivation:')
eq(r"\mathcal A(D,\nu)=\tfrac12\|D-A^{\dagger}\nu\|^2+\tfrac12\|\nu\|^2","neutral_functional")
p('Stationarity yields (I+AA†)ν=AD. Substitution gives the minimized value ½⟨D,C_N(Y)D⟩. This eliminates ν for a specified A; it does not determine A or the next master load. The identity C_N+B_N=I partitions the corresponding quadratic form exactly but does not by itself conserve the graph energy along a reclosure step.')
p('For the finite real formation problem used upstream, take a symmetric formation operator Kf and the quartic admissibility functional')
eq(r"K_f=c+\aleph-D_{\rm cap},\qquad \mathcal F(\delta)=\tfrac12\langle\delta,K_f\delta\rangle+\tfrac14\|\delta\|^4","formation")
p('If its smallest eigenvalue λ1 is simple and negative, radial minimization after the Rayleigh bound gives the two minima ±√(−λ1)e1. The remaining spectral gap isolates the direction. This is a finite mathematical formation result, not an observed cosmological transition. For the complex SA model below, formation is used through its self-adjoint spectral conditions; the real two-minimum statement is not silently transferred to complex phase orbits.')
p('The master reconstruction in the source architecture takes the form')
eq(r"B_C=D_{\rm cov}c,\quad H_C=B_C^{\dagger}W_NB_C,\quad Y=L_C^{\dagger}H_CL_C","factorization")
p('With W_N nonnegative, the Gram construction ensures positivity. Numerical values and evolution still depend on the definitions of D_cov, W_N and L_C. In the finite completion, D_cov c is explicitly interpreted as operator composition. A covariant derivative of a field is a different construction and requires its own connection and field data. This distinction matters when comparing compression to a fresh reconstruction.')

page('3 Repair of persistent geometry')
p('The bounded nondecay span used in the canonical source line [4,5] is not generally equal to the peripheral spectral subspace. The defect can be shown without numerical approximation. Let R=diag(1,1/2). Both e1 and e1+e2 have bounded orbits whose norms do not tend to zero. Their span nevertheless contains e2, which decays. Consequently')
eq(r"\operatorname{span}\{z:\sup_k\|R^kz\|<\infty,\ \limsup_k\|R^kz\|>0\}=\mathbb C^2","bad_witness")
p('for this example, whereas the peripheral space is span(e1). Closing the span does not repair the finite-dimensional failure. We therefore use the following explicitly repaired definition when the finite peripheral block is isolated:')
eq(r"W=\operatorname{Ran}P_{\rm sp},\qquad P_{\rm sp}=\frac1{2\pi i}\oint_{\Gamma}(zI-R)^{-1}\,dz","riesz")
p('Here Γ encloses precisely the unit-modulus eigenvalues. In finite dimension, power boundedness excludes nontrivial Jordan blocks on the unit circle; the stable generalized eigenspaces decay. These assumptions must be checked, not inferred from a plot of eigenvalues near the unit circle.')
p('The spectral projection and the projection appropriate to the master metric have different purposes. If Z has columns forming a basis of W, then')
eq(r"P_G=Z(Z^{\dagger}GZ)^{-1}Z^{\dagger}G","metric_projector")
p('is the G-orthogonal projector. Its formula is basis independent, P_G²=P_G and P_G†G=GP_G. The Riesz projector commutes with R but need not be orthogonal in G. Equality holds precisely when the stable spectral complement is the G-orthogonal complement of W. For R=[[1,1],[0,1/2]] and G=I, the spectral projection is [[1,2],[0,0]], while the metric projection onto span(e1) is diag(1,0).')
sub('A finite nonnormal certificate')
p('A supplied invariant decomposition can be checked exactly over rational arithmetic [9]. Suppose S is invertible and M,N are positive definite, with')
eq(r"S^{-1}RS=\operatorname{diag}(A,T),\quad A^{\mathsf T}MA=M,\quad N-T^{\mathsf T}NT\succ0","certificate")
p('The first block is an isometry in M. Compactness of the N-unit sphere makes T a strict contraction in N. Similarity by S then proves power boundedness and identifies the peripheral and stable spaces. This certifies supplied data; it neither discovers a certificate for every operator nor derives the next recursion operator from BFG. Empty blocks require explicit conventions.')

page('4 Polar transport and Gram compatibility')
p('The persistent keep and upward branches are P_G C_N D and P_G B_N D. Let their positive graph loads be Λkeep and Λup. Normalization and reciprocal balance give ωkeep=Λup/(Λkeep+Λup) and ωup=Λkeep/(Λkeep+Λup). For these specified loads the weights are unique. The cross-fed analysis and packet are')
eq(r"\mathcal A=\begin{bmatrix}\sqrt{\omega_{\rm keep}}P_GC_N\\\sqrt{\omega_{\rm up}}P_GB_N\end{bmatrix},\qquad p=\mathcal A D","analysis")
p('The polar partial isometry is fixed on the active support. Writing a plus sign for the Moore–Penrose inverse,')
eq(r"Q=(\mathcal A^{\dagger}\mathcal A)^{1/2},\quad J=\mathcal A Q^+,\quad E=JJ^{\dagger}","polar")
p('gives the new carrier H′=Ran(E). The capacities are compressed on that carrier:')
eq(r"A_{\rm cap}'=E(A_{\rm cap}\oplus A_{\rm cap})E\big|_{H'},\quad A_{\rm cap}\in\{D_{\rm cap},c,\aleph\}","capacity")
p('This operation preserves self-adjointness and positive lower bounds where present. It does not automatically make a separately reconstructed Gram operator equal to the compression of the old one. A sufficient compatibility condition, in coordinates U for the new carrier, is B2U=UB′, L2U=UL′ and W′=U†W2U, where B2=B⊕B and similarly for W,L. Direct substitution then gives Y′=U†(Y⊕Y)U.')
p('The stronger intertwining requirement cannot be replaced by compression alone. If W=L=I and B′=U†B2U, the exact defect is')
eq(r"U^{\dagger}B_2^{\dagger}B_2U-B'^{\dagger}B'=F^{\dagger}F,\quad F=(I-UU^{\dagger})B_2U","leakage")
p('Thus equality holds exactly when the discarded output channel F vanishes. This positive defect identifies the missing information rather than allowing it to be removed by notation. A local derivative example makes the failure concrete: take c(t)=I+tS with S=[[0,1],[1,0]], D_cov=∂t and retain e1. Then B=S and Y=I, but the compressed coherence is constantly one, its derivative is zero and its freshly reconstructed Gram load is zero. The inherited load is one. Here t is a local field coordinate, not the iteration index. The example excludes a general equality in this class; it does not exclude every possible connection law.')

page('5 An explicit finite closure model')
p('We now define the finite self-adjoint completion, denoted CTC-SA in the repository [9]. The name labels this particular completion, not a theorem that all BFG realizations belong to it. Its primitive state consists of H, three capacities, an active vector D and a scalar η. Assume d≥2, commuting self-adjoint capacities, c≥c*I>0, and')
eq(r"\lambda_1(K_f)<0<\lambda_2(K_f)<\cdots<\lambda_d(K_f),\quad \eta>0,\quad Y=\eta I","sa_class")
p('Every spectral component of D is required to be nonzero. The following are additional model rules:')
eq(r"W_N=L_C=N_R=I,\quad D_{\rm cov}=\sqrt\eta\,c^{-1},\quad B_C=\sqrt\eta I","sa_factors")
eq(r"P_s=P_{\lambda_d}(K_f),\quad P=I-P_s,\quad r=\frac{\lambda_{d-1}-\lambda_1}{\lambda_d-\lambda_1},\quad R=P+rP_s","sa_recursion")
p('For d=2 the ratio is zero. For d≥3 it lies strictly between zero and one. Thus R is normal, P is its peripheral projector, and because G is scalar P is also the metric projector. These rules choose a particular factorization, stable eigenline and decay factor. Their selection is examined below.')
p('For a nonterminal state define')
eq(r"a(\eta)=\frac{\eta}{(1+\eta)\sqrt{1+\eta^2}},\quad t=\frac{\|PD\|^2}{\|D\|^2},\quad q=2a(\eta)^2t","gain")
p('The two reciprocal packet components become equal: A=a[P;P]. Hence J=[P;P]/√2 on Ran(P), and capacity transport is unitarily equivalent to keeping the first d−1 eigenlines. The reference next-load rule is g=q. In support coordinates the complete nonterminal update is')
eq(r"\eta'=q,\quad Y'=qI,\quad D'=\frac{\sqrt2a(\eta)}{1+q}PD","sa_update")
p('All reconstructed factors and R′ are rebuilt from the new capacities and η′ by the same rules. The output is the full structured state, not just D′. For d=2 the map is defined to return the absorbing terminal object ⊥, with U(⊥)=⊥. This terminal convention is an explicit policy of the completion. It is not a proof that one-dimensional negative quartic formation is mathematically impossible.')

page('6 Conditional closure and contraction')
sub('Proposition 1 Finite closure')
p('Under the assumptions of Section 5, every d≥3 state maps to an admissible state of dimension d−1. The resulting sequence has exactly d0−2 nonterminal transitions before reaching dimension two; the next application returns ⊥.')
p('Proof. Commuting self-adjoint capacities share the simple formation eigenbasis. Restriction to the first d−1 lines preserves commutation, self-adjointness and the lower bound on c. The retained formation spectrum remains simple with exactly one negative eigenvalue and at least one positive eigenvalue. Full support gives 0<t<1 and hence q>0. Multiplication of PD by a strictly positive scalar leaves every retained spectral component nonzero. Reapplying the declared factor and recursion rules therefore produces the same type of state. Induction reduces the dimension until the explicitly defined terminal rule applies. This proves closure of the stated finite class, not infinite nonterminal evolution.')
sub('Proposition 2 Structural energy contraction')
p('Define E=||D||²G=(1+η)||D||². This is a structural quadratic quantity; no joule-valued interpretation is asserted. Direct substitution gives')
eq(r"\frac{E'}E=\frac{q}{(1+q)(1+\eta)}","energy_ratio")
p('The needed uniform bound follows from an exact polynomial identity:')
eq(r"(1+\eta)^2(1+\eta^2)-8\eta^2=(\eta-1)^2(\eta^2+4\eta+1)\geq0","polynomial")
p('Therefore a²≤1/8 and, because t<1, q<1/4. It follows that E′/E<1/5, so E_n≤5^(−n)E_0 for every existing nonterminal prefix. This conservative bound is not claimed to be sharp. It applies to the actual unforced SA trajectory; it is not a uniform switching theorem or a bound for arbitrary external inputs.')
p('There is also a strict distinction between reconstruction and inheritance. Compression of the old scalar Gram operator gives ηI, whereas the reference model rebuilds qI. Since q/η=2ηt/[(1+η)²(1+η²)]<1, the two disagree at every nonterminal step. The compatibility result in Section 4 cannot be cited as a derivation of this fresh-load rule.')
table(['Dimension','Scalar load η','Structural energy E'],[
 ('5','1','10'),('4','1/5','5/6'),('3','25/624','625/23364'),('2','324480000/164268811201','3515200000000/69326858847152401')],[.8,2.2,3.3],'Exact reference trajectory for c=diag(1,2,3,4,5), aleph=I, Dcap=diag(3,1,1,1,1) and D=(1,1,1,1,1).')

page('7 Four choices that are not uniquely selected')
p('Consistency does not make the selected completion unique. The following constructive alternatives preserve the explicitly compared weaker structural conditions. They are different model laws, not additional solutions of the already fully specified reference model.')
sub('7 1 Gram factors')
p('In finite square dimension, for positive W, invertible L and unitary V, set')
eq(r"D_{\rm cov}=\sqrt\eta\,W^{-1/2}VL^{-1}c^{-1}","factor_family")
p('Then B_CL=√η W^(−1/2)V and L†B_C†WB_CL=ηI. Conversely, V=η^(−1/2)W^(1/2)B_CL is unitary whenever this identity holds. Thus the factors are not determined by the Gram operator alone. With W=L=I and the additional condition B_C≥0, the positive square root uniquely selects B_C=√ηI. Equal Gram operators imply identical reduced updates only when the factors enter through Y alone; physical gauge equivalence has not thereby been established.')
sub('7 2 Next load')
p('For any fixed finite positive next load g, the same packet and final resolvent give')
eq(r"\frac{E'}E=\frac{q}{(1+g)(1+\eta)}<\frac14","general_energy")
p('Hence g=q, q² and q/2 are all positive and dissipative. At the initial state of Table 1 they produce next loads 1/5, 1/25 and 1/10 and energies 5/6, 25/26 and 10/11 respectively. They make distinguishable primitive-state predictions. Reciprocal balance determines the old packet weights, not the new load.')
sub('7 3 Stable mode and decay rate')
p('Removing the smallest positive formation eigenline instead of the largest retains one negative mode, positivity of c and a valid next formation spectrum. For diag(−1,2,3,4,5), the next spectrum becomes (−1,3,4,5) instead of (−1,2,3,4). A rank-one upper-tail filter would select the largest line, but that filter is an extra premise. For fixed P, the two decay rules satisfy')
eq(r"R_1=P+r(I-P),\quad R_2=P+r^2(I-P)=R_1^2","rate_ambiguity")
p('They share the same peripheral space and, in this completion, the same primitive state trajectory, but differ in R and its persistence gap. At a frozen state, one R2 step equals two R1 steps. Rate discrimination therefore requires an independently fixed recursion-time convention. These four choices do not exhaust every assumption of the SA completion.')

page('8 Packet information and the reconstruction contract')
sub('Proposition 3 Packet insufficiency')
p('If T maps a full old state to its packet and transported capacities, a quantity h(X) can be written as F(T(X)) exactly when it is constant on every fiber of T. Necessity follows by substitution. Conversely, assigning F to any representative of a fiber is well-defined precisely under this condition.')
p('For a concrete collision take d=3, c=diag(1,2,3), aleph=I, Dcap=diag(3,1,1), η=1 and')
eq(r"K_f=\operatorname{diag}(-1,2,3),\quad P=\operatorname{diag}(1,1,0),\quad D_z=(1,1,z),\quad z>0","collision_state")
p('The packet is always a(1,1,0;1,1,0), with a=1/(2√2). The new support, transported capacities and packet therefore agree for all z. In support coordinates p=(1/2,1/2), but')
eq(r"q(X_z)=\frac{1}{2(2+z^2)}","collision_gain")
p('takes values 1/6 and 1/12 at z=1 and z=2. Squaring or halving q preserves this distinction. None of the three laws is therefore a function of the packet and transported capacities alone. The argument is conditional on this restricted input contract; the source notation B_C[p] does not establish that all old-state dependence is forbidden.')
sub('Proposition 4 A sufficient scalar input')
p('Because the old master metric is scalar, its factor cancels from the packet-gain quotient:')
eq(r"q=\frac{\|p\|_{G\oplus G}^{2}}{\|D\|_G^{2}}=\frac{\|p\|^2}{N},\qquad N=\|D\|^2>0","sufficient_input")
p('Thus the old squared norm is a sufficient additional scalar for the three candidate laws. It is computed from the old state and is not a new freely fitted parameter. At each iteration the new norm is computed from D′; no unlimited history is needed. In general nonscalar geometry this cancellation is unavailable.')
p('The explicit scalar reconstruction contract consists of the new carrier, transported capacities, packet p, old norm N and a single fixed model function h. It returns g=h(q), Y′=gI, the factors of Section 5 and D′=p/(1+g), together with all structural state data. Choosing h once gives an executable model. It does not prove that BFG uniquely requires h(q)=q. Smoothness, positivity, monotonicity and h(0)=0 leave the three alternatives admissible. Even h′(0)=1 leaves h(q)=q+q². Any stronger normalization or additivity principle needs independent justification.')

page('9 Simulation design and packet gain surface')
p('The new simulations are deterministic evaluations of the finite completion. They introduce no fitted observations and no random samples. We used a grid of 121 logarithmically spaced η values from 0.05 to 4 and 101 linearly spaced retained fractions t from 0.02 to 0.98, yielding 12,221 states. At each state we evaluated a, q and the three responses. The complete numerical grid and software versions are included in the supplement.')
figure('Figure_1_packet_gain_3D','Synthetic packet-gain surface q=2a(η)²t. The horizontal axes are log10 η and the retained squared-norm fraction t; the vertical axis and color show q. Each surface point is a formula evaluation, not a measured physical state. The largest sampled value is 0.24500 approximately; the analytic bound q<1/4 is proved in Section 6, not inferred from the grid. The surface maximum lies near η=1 and t near one. No universality conclusion follows from its smoothness.')
p('The surface separates a current load from a transition quantity. In particular, a high or low η can both give a small packet gain, so q is not an interchangeable name for η. The t dependence is linear for fixed η. The upper bound follows from reciprocal weighting and the neutral scalar response, before any choice of h for the next load. Consequently all three next-load laws inherit this same upstream packet surface.')
p('This finite sweep tests numerical consistency across a broad illustrative range. It does not sample the full class of BFG operators, replace a proof at untested parameter values, or establish a physical distribution of initial conditions. The exported three-dimensional plot is a graph of scalar variables rather than a simulation of three-dimensional physical space.')

page('10 Competing neutral response surfaces')
p('The most direct scalar discriminator is the next neutral response s=1/(1+g). Figure 2 evaluates this quantity for the three competing laws over the identical upstream grid. They agree in the zero-gain limit but separate at finite q. This is prospective model discrimination: no measured response has been used to select one surface.')
figure('Figure_2_competing_responses_3D','Synthetic response surfaces for g=q, g=q² and g=q/2. Axes show log10 η, retained fraction t and next scalar response s. Colors distinguish fixed candidate laws, with no stage-specific adjustment. For 0<q<1/4, the q law gives the lowest response, q² the highest and q/2 an intermediate response. The wireframe display allows overlap to be inspected. These surfaces are alternative mathematical predictions, not fitted empirical response sheets.')
p('At q=1/5, the three responses are 5/6, 25/26 and 10/11. Their smallest separation is 15/286. For exactly known q, a deterministic absolute response error bound smaller than 15/572 would make their expanded prediction bands disjoint. If q is known only within [0.19,0.21], the corresponding sufficient bound becomes 50900/2286579, approximately 0.02226. These are algebraic design thresholds, not achieved experimental accuracies.')
p('A measurement must identify s without constructing it from the selected h. Multiple independently calibrated probe directions would also be needed to test a claimed scalar response operator. A single input-output ratio does not demonstrate isotropy, and a frequency response with phase cannot be replaced by a positive scalar response without a justified map.')

page('11 Finite trajectories under three fixed laws')
p('We next evolve the d0=5 seed of Table 1 with each candidate h held fixed throughout. Every model deletes the same largest positive formation mode and applies the same dimension-two terminal convention. The only changed law is the fresh scalar Gram load. Figure 3 follows carrier dimension, load and structural energy; it does not identify recursion depth with elapsed physical time.')
figure('Figure_3_finite_trajectories_3D','Deterministic finite trajectories starting from D=(1,1,1,1,1) and η=1. The three axes are dimension, log10 η and log10 structural energy E. Lines connect the four states of each discrete sequence and serve only as visual guides. Each reaches dimension two after three nonterminal steps; the next map application is terminal. Different amplitudes and energies coexist with the same dimension sequence. Thus dimension reduction alone cannot identify the load law.')
p('All plotted values are strictly positive before terminality, making the logarithms well-defined. The reference first step matches the exact values η′=1/5 and E′=5/6. The q² completion can suppress the next load far more rapidly, while its final resolvent attenuates the current packet less strongly for the same q. These statements refer to separate quantities and do not contradict each other.')
p('The published reference implementation has a numerical admissibility tolerance; it is not an exact solver for arbitrarily tiny loads. Fourteen focused tests were rerun for this preprint and passed. The earlier 143-test full-suite result remains a historical result of its documented run; it was not rerun or relabelled as new evidence. The figure calculations use explicit diagonal support coordinates, preserve the same finite assumptions and are independently supplied.')

page('12 Measured impedance and conventional reconstruction')
p('To investigate a possible physical interface, we used the open RLC spectrum collected by Danzer, Plank and Rüther at the University of Bayreuth [10]. The unmodified file contains 81 frequencies between 99.968163 and 10002.226 Hz and complex impedance values. The record describes a capacitor in parallel with a lossy inductor. These are external experimental data, distinct from the synthetic SA simulations.')
eq(r"Z(\omega)=\left[\frac{1}{R+i\omega L}+i\omega C\right]^{-1}=\frac{R+i\omega L}{1+i\omega C(R+i\omega L)}","rlc_impedance")
p('Positive R,L,C were estimated from 41 alternating points in the frequency-sorted spectrum by minimizing equal-frequency relative complex squared residuals:')
eq(r"\mathcal L(R,L,C)=\sum_{k\in\mathcal I_{\rm fit}}\frac{|Z_{\rm model}(\omega_k)-Z_k|^2}{|Z_k|^2}","rlc_loss")
p('The remaining 40 interleaved points provide an interpolation check within the same sweep. The data had already been inspected, so this is exploratory rather than blinded or preregistered. Three initial parameter vectors converged to the same fitted values. An independent Kirchhoff-admittance expression, the DC limit, redundant data fields and synthetic parameter recovery were checked.')
table(['Quantity','Result'],[
 ('Fitted resistance','9.53528 Ω'),('Fitted inductance','4.84889 mH'),('Fitted capacitance','2.18313 µF'),('Relative complex RMS on fit points','1.5926%'),('Relative complex RMS on interpolation points','1.5958%'),('Maximum relative complex error on interpolation points','4.2743%'),('Complex RMS on interpolation points','1.90883 Ω')],[3.65,2.65],'Exploratory conventional RLC fit. Error percentages are defined by the relative complex residual, not confidence intervals.')
p('The source description lists 9.7 mΩ, whereas the fit and low-frequency impedance are compatible with a loss resistance near 9.7 Ω. The exact nominal parameter set gives about 107.4% relative complex RMS error over all frequencies. A metadata unit error or unreported losses are possible, but neither explanation is established here. Nominal component tolerances are not per-point impedance uncertainty bounds. The original description is preserved unchanged.')

page('13 The measured spectrum in three coordinates')
figure('Figure_4_RLC_spectrum_3D','Experimental impedance spectrum and conventional circuit reconstruction. The axes are log10(f/Hz), Re Z in ohms and Im Z in ohms. Orange markers are all 81 measured spectrum points; the blue curve evaluates the three-parameter fit, which used only the designated 41 fitting frequencies. The remaining 40 points are interpolation controls from the same measured sweep, not a separate experiment. The plot is a three-coordinate representation of a frequency response, not a three-dimensional spatial simulation. Source data are credited in reference [10], under CC BY 4.0.')
p('The frequency coordinate makes the change from inductive to capacitive response visible without discarding phase. The fitted inductance and capacitance are close to their nominal values, while the resistance discrepancy must remain visible in the evidence ledger. A small curve residual is evidence about this conventional circuit approximation only.')
p('We have not supplied an uncertainty model sufficient to decide whether the remaining residuals are instrument noise, component nonideality or omitted topology. Nor does the processed spectrum contain the full original current and voltage time traces, repeated state preparations or transitions between independently observed BFG carriers. Those omissions limit the use of the data for the next-load discrimination proposed in Section 10.')
p('The source file was checked against its published MD5 checksum, and a SHA-256 digest is recorded in the supplement. Numerical data and code are archived separately from the interpretation. No claim is made that the data collectors endorse the BFG framework or this use of their measurements.')

page('14 Why the direct RLC realization does not close CTC')
p('The spectrum cannot be identified directly with a positive dimensionless Gram operator: impedance is complex, dimensional and frequency dependent. Forming a nonnegative scalar from its magnitude can create a positive quantity, but choosing a normalization and setting Y=1/s−1 would construct the desired response algebraically rather than predict it independently.')
p('There is also a sharper obstruction to identifying the BFG recursion with the autonomous physical circuit dynamics. With capacitor voltage v and inductor current i as the state, the zero-input circuit has')
eq(r"\frac{d}{dt}\begin{bmatrix}v\\i\end{bmatrix}=A\begin{bmatrix}v\\i\end{bmatrix},\qquad A=\begin{bmatrix}0&-1/C\\1/L&-R/L\end{bmatrix}","rlc_state")
eq(r"\det(\lambda I-A)=\lambda^2+(R/L)\lambda+1/(LC)","rlc_poles")
p('For strictly positive R,L,C both roots have negative real part. At the fitted parameters they are approximately −983.245 ± 9669.522 i s⁻¹. Hence, for every positive sampling interval Δt, every eigenvalue of exp(AΔt) lies strictly inside the unit circle. Its peripheral Riesz space is empty. This analytical conclusion does not depend on a near-unit numerical threshold.')
p('Under that direct identification, the nontrivial persistent sector required by the SA generator is absent. A sinusoidal forced response can persist because the source continues to supply energy; it is not a nondecaying eigenmode of the free circuit. Adding the source as an autonomous state or replacing physical-time propagation by another recursion would define a new realization problem. Such changes cannot be used as an unreported rescue of the present test.')
p('The conventional state dimension is also two. The declared SA completion terminates at dimension two, so these measurements do not provide an observed nonterminal SA trajectory. The conclusion is restricted: this data set and direct dynamical assignment do not select h(q), and do not instantiate the desired CTC transition. This is not a proof that no circuit, driven system or other construction could ever realize a differently specified BFG sector.')
sub('Consequence for empirical work')
p('The RLC study has value as an externally grounded negative eligibility test. It shows why a familiar physical response and a good fit are insufficient. The next candidate must provide an independently motivated state map, an appropriate persistent structure and independently identifiable transition quantities. Searching only for another data set with a smooth curve would not address these missing requirements.')

page('15 Nonnormal and infinite dimensional boundaries')
p('The exact finite nonnormal certificate of Section 3 is a useful partial result. It allows supplied rational invariant splittings and Lyapunov metrics to be verified without eigenvalue rounding. It does not establish automatic reconstruction of these data, a universal update of R, or existence of a certificate for every desired BFG state [9].')
p('A separate gap concerns local field evolution. Let S=[[0,1],[1,0]] and c_a(t)=I+(t+a t^(m+1))S near t=0. For any fixed finite m≥1, every a gives the same derivatives of c through order m at zero, yet the next derivative depends on a. Each field is locally positive for a sufficiently small interval. A finite list of local derivative data therefore cannot determine the unrestricted next derivative without an evolution law. This is a statement about the local field coordinate t, not a general impossibility theorem for a separately defined discrete state map.')
p('For unbounded operators, the neutral resolvent core extends naturally if K is closed and densely defined:')
eq(r"Y=K^{\dagger}K\geq0,\quad C_N=(I+Y)^{-1},\quad \mathcal Q(Y)=\operatorname{Dom}(K)","unbounded")
p('The form-domain norm is ||x||²+||Kx||². Bounded resolvents alone do not guarantee that the next transported carrier lies in a suitable form domain. On ℓ²(N), take the closed diagonal operator (Kx)n=n xn, with domain determined by Σn²|xn|²<∞. Then')
eq(r"v=(1,1/2,1/3,\ldots)\in\ell^2\setminus\operatorname{Dom}(K),\quad Uz=zv/\|v\|","domain_counterexample")
p('defines a Hilbert-space isometry U from C into ℓ², but KU has domain {0}, which is not dense in C. Thus isometry alone does not ensure a densely defined Gram form on the new carrier. An admissible iteration must prove dense definition and closability of the relevant compositions, or impose stronger graph-norm mapping conditions. This explicit counterexample cannot be repaired by observing positivity of finite truncations.')
p('The unbounded resolvent theorem is therefore a component, not a complete infinite-dimensional reclosure theorem. Spectral isolation, domains, metric projection and transport compatibility require their own preservation arguments. The current finite simulation figures carry no evidence that these infinite-dimensional obligations have been met.')

page('16 Status of the seven closure problems')
p('Table 4 states the closure status as of 21 September 2026. “Conditional finite result” means that an explicit result exists under declared assumptions; it does not mean that the original universal claim has been proved. The distinction is essential because an executable selected model can coexist with unresolved selection of its laws.')
table(['Problem','Established result','Remaining obligation'],[
 ('1 Full state update','Structured finite SA update and explicit terminal rule','General BFG state category and uniquely justified reconstruction'),
 ('2 Reconstruction of B_C W_N L_C','Explicit finite factors; complete square-factor freedom at fixed scalar Y','Unique upstream factor construction and geometric interpretation'),
 ('3 Full Gram rebuild','Positive finite rebuild; exact conditional compatibility and defect','Selection of the next-load law and general transport compatibility'),
 ('4 Recursive transport','Selected SA spectral rule; supplied nonnormal certificates','Internally determined general R_next and invariant domains'),
 ('5 Universal iteration','Finite terminating closure by induction','Universality beyond the chosen class; nonterminal infinite evolution if claimed'),
 ('6 General nonnormal case','Exact verification of supplied rational splittings and metrics','General constructive update and persistence selection'),
 ('7 Infinite dimensional realization','Closed-operator resolvent core and domain counterexample','Iterated domain preservation and a validated physical realization')],[1.38,2.2,2.72],'Seven original closure obligations and their current bounded status.')
sub('Research priorities')
p('The next theoretical step is a source-grounded condition selecting h or a more general reconstruction functional. A relabelled normalization is insufficient. Any new condition must state its domain, relation to the existing sources and consequences for the explicit alternatives. Retaining these alternatives is useful because they make the missing information testable.')
p('The next empirical step is a concrete state and measurement map with a fixed error model. The old packet gain and new neutral response must be determined separately, and the target system must satisfy the persistence and carrier assumptions before a fit is interpreted. If no map is available, the empirical claim remains untested. Failure at this eligibility stage should be recorded rather than hidden by choosing different variables after viewing the result.')
p('Broader physical claims, including recovery of established theories or universal descriptions of natural systems, require additional reductions and independent data. The present paper neither derives their numerical constants nor supplies those validation results.')

page('17 Conclusions and reproducibility')
p('BFG now has a documented finite completion with an explicit structured state, a provable terminating iteration and a structural-energy contraction estimate. Its neutral identities, repaired finite persistent geometry, conditional Gram compatibility and rational nonnormal certificates are mathematically substantive within their stated domains. The packet-collision proof further locates a specific information loss and shows how the scalar update can be made computationally explicit.')
p('The same analysis prevents a stronger conclusion. Four selected rules are not uniquely forced by the compared premises; a definition of the old-state input does not select the new load law. General nonnormal reconstruction and infinite-dimensional domain preservation remain open. The measured RLC study supplies a reproducible conventional fit and a negative result for the direct CTC realization, not a positive test of BFG. This combination is the current defensible status: improved conditional mathematics and auditability, with universal and empirical closure still unestablished.')
sub('Data and code availability')
p('The author’s source manuscripts, audit stages and numerical reference implementation are identified in references [1–9]. The external impedance file is reference [10]. The companion archive contains this manuscript’s builder, simulation script, 12,221-row grid, finite trajectories, run manifest, four PNG and four SVG figures, RLC analysis code, unmodified RLC data and provenance, results, and SHA-256 checksums. Files are named to preserve the distinction between source data and derived outputs. The raw RLC file is redistributed under CC BY 4.0 with attribution; it is not author-generated data.')
p('The fresh reference check ran 14 focused tests successfully. The new parameter sweep and trajectories were recomputed for this preprint. The RLC fit and its unit, checksum and synthetic-recovery checks were rerun in the preceding analysis stage. No statistical confidence intervals are claimed for the RLC fit because a defensible measurement-error model was not supplied. The figures are static projections of three-dimensional mathematical plots; the supplement provides data and vector exports for reuse.')
sub('Authorship and assistance')
p('Marcel Theodor Wende is the author of the BFG research program and this requested preprint. The supplied BFG manuscripts identify earlier source-line contributions involving Thomas W. Loker and Luke Kenneth Casson Leighton; this paper does not reassign those contributions or add them as authors without authorization. The external RLC measurements retain the credit of their original collectors.')
p('AI assistance was used for manuscript drafting, mathematical cross-checking, code preparation and document layout. This assistance is not independent peer review. The document is a preprint prepared for author review; no claim is made that a journal, institution, collaborator or data provider has approved its conclusions. Funding and competing-interest declarations beyond information supplied for this work have not been inferred.')
sub('Supplementary figure use')
p('Figures 1–3 are newly generated synthetic calculations of the declared finite model. Figure 4 combines independently collected measured data with the conventional circuit fit. Each caption states axes, interpretation and limits. Source files, data and rendered figures are separated in the archive so that the numerical work can be checked without relying on the document layout.')

page('18 References')
references=[
'Wende, M. T. BFG Universal Structural Whitepaper Strong Form V2. Author-supplied manuscript, 2026. File: BFG_Universal_Structural_Whitepaper_Strong_Form_V2.docx. Sections 6, 23 and 24 are central to this audit.',
'Wende, M. T. The BFG Universal Reclosure Unification Whitepaper. Revised final author manuscript, 7 September 2026. File: BFG_Universal_Reclosure_Unification_Whitepaper_2026-09-07_revised_final.pdf.',
'Wende, M. T. The BFG Strong Universal Reclosure Whitepaper. Author manuscript, 8 September 2026. File: BFG_Strong_Universal_Reclosure_Whitepaper_2026-09-08.pdf.',
'Wende, M. T. The BFG Endogenous Dual-Order Strong Universal Reclosure Equation — Canonical Closure Edition. Author manuscript, 8 September 2026. File: BFG_Endogenous_Dual_Order_Strong_Universal_Canonical_Closure_Whitepaper_2026-09-08.pdf.',
'Wende, M. T. The BFG Compact Canonical Universal Reclosure Equation — Freedom-Closed Unified V4. Author manuscript, 12 September 2026. File: BFG_Unified_V4_Compact_Canonical_Universal_Reclosure_2026-09-12.pdf. The referenced V3 predecessor has not been established as an available source in this audit and is not treated as supporting evidence.',
'BFG Audit Complete Edition. Author-supplied methodological document, undated. File: BFG_Audit_Complete_Edition.docx. Provenance hash is supplied in the companion manifest.',
'BFG Audit Workflow Master. Author-supplied methodological document, undated. File: BFG_Audit_Workflow_Master.docx. Provenance hash is supplied in the companion manifest.',
'BFG X Context Recovery Protocol Master. Author-supplied methodological document, undated. File: BFG_X_Context_Recovery_Protocol_Master finish.docx. Provenance hash is supplied in the companion manifest.',
'Wende, M. T. BalanceFieldResearch. Research repository, source baseline e6670bc4a662ffdcb0d54345b6fbbc02be327f1e, accessed 21 September 2026. https://github.com/marceltheodorwende-ops/BalanceFieldResearch/tree/e6670bc4a662ffdcb0d54345b6fbbc02be327f1e . Relevant stages: gram-compatibility, exact-nonnormal, closure-boundaries, ctc-audit, ctc-reference, next-gram-identifiability, rebuild-input-contract, load-law-discrimination and rlc-realization.',
'Danzer, M. A.; Plank, C.; Rüther, T. Impedance data for various electrochemical and electrical systems. Version 1.0.0, Zenodo, 2024. DOI: 10.5281/zenodo.10794584. https://doi.org/10.5281/zenodo.10794584 . RLC file: rlc_circuit.json. Data license: Creative Commons Attribution 4.0 International. Accessed 21 September 2026.'
]
for n,ref in enumerate(references,1):
 pp=p('['+str(n)+'] '+ref);pp.paragraph_format.space_after=Pt(8)
 for run in pp.runs:run.font.size=Pt(10)

# Correct a cross-reference to the seed table (Table 2, not the notation table).
for para in doc.paragraphs:
 if 'Table 1' in para.text and not para.text.startswith('Table 1.'):
  for run in para.runs:run.text=run.text.replace('Table 1','Table 2')

out=OUT/'BFG_Mathematical_Foundations_and_Path_to_Empirical_Validation_2026-09-22.docx'
# Remove inherited theme borders and force explicit scholarly fonts.
for style in doc.styles:
 for border in list(style.element.findall('.//' + qn('w:pBdr'))):border.getparent().remove(border)
 if style.name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
  rf=style.element.get_or_add_rPr().get_or_add_rFonts()
  for key in list(rf.attrib):
   if 'Theme' in key:del rf.attrib[key]
  rf.set(qn('w:ascii'),'Times New Roman');rf.set(qn('w:hAnsi'),'Times New Roman')
for para in doc.paragraphs:
 for border in list(para._p.findall('.//' + qn('w:pBdr'))):border.getparent().remove(border)
doc.save(out)
(OUT/'manuscript_index.json').write_text(json.dumps({'equations':eqs,'figures':figs,'tables':tables,'references':references},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(OUT/'manuscript_text.txt').write_text('\n'.join(x.text for x in doc.paragraphs),encoding='utf-8')
print(out);print('equations',len(eqs),'figures',len(figs),'tables',len(tables),'references',len(references))

