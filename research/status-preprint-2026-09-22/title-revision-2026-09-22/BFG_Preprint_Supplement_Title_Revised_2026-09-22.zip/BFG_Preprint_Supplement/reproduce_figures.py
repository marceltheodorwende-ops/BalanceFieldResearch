import sys,json,csv,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
import os
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.mplconfig'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=ROOT
FIG=OUT/'figures'; DATA=OUT/'simulation_data'
FIG.mkdir(parents=True,exist_ok=True);DATA.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,'axes.labelsize':10,'figure.dpi':150,'savefig.dpi':240})

def save(fig,name):
    fig.savefig(FIG/(name+'.png'),bbox_inches='tight',pad_inches=.25)
    fig.savefig(FIG/(name+'.svg'),bbox_inches='tight',pad_inches=.25)
    plt.close(fig)

etas=np.geomspace(.05,4,121); ts=np.linspace(.02,.98,101)
eta,t=np.meshgrid(etas,ts); a=eta/((1+eta)*np.sqrt(1+eta*eta)); q=2*a*a*t
assert np.all((q>0)&(q<.25))
fig=plt.figure(figsize=(7.2,4.7));ax=fig.add_subplot(111,projection='3d')
surf=ax.plot_surface(np.log10(eta),t,q,cmap='viridis',rstride=2,cstride=2,linewidth=0,antialiased=True)
ax.set(xlabel=r'$\log_{10}\eta$',ylabel=r'$t=\|PD\|^2/\|D\|^2$',zlabel=r'$q=2a(\eta)^2t$')
ax.view_init(28,-132);fig.colorbar(surf,ax=ax,shrink=.58,pad=.12,label='Packet gain q')
save(fig,'Figure_1_packet_gain_3D')

fig=plt.figure(figsize=(7.2,4.7));ax=fig.add_subplot(111,projection='3d')
surfaces=[('q',q,'#176B87'),('q squared',q*q,'#D66A1F'),('q over 2',q/2,'#7657A3')]
for label,g,color in surfaces:
    ax.plot_wireframe(np.log10(eta),t,1/(1+g),rstride=10,cstride=12,color=color,linewidth=.55,label=label)
ax.set(xlabel=r'$\log_{10}\eta$',ylabel='Retained fraction t',zlabel=r'$s=1/(1+g)$')
ax.view_init(22,-131);ax.legend(loc='upper left',fontsize=9)
save(fig,'Figure_2_competing_responses_3D')
with (DATA/'surface_grid.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['eta','t','q','response_q','response_q_squared','response_q_half'])
    for e,tt,qq in zip(eta.flat,t.flat,q.flat):w.writerow([e,tt,qq,1/(1+qq),1/(1+qq*qq),1/(1+qq/2)])

rows=[]
fig=plt.figure(figsize=(7.2,4.7));ax=fig.add_subplot(111,projection='3d')
for name,func,color in [('q',lambda x:x,'#176B87'),('q squared',lambda x:x*x,'#D66A1F'),('q over 2',lambda x:x/2,'#7657A3')]:
    d=np.ones(5);e=1.;points=[]
    while True:
        energy=(1+e)*float(d@d);points.append((len(d),np.log10(e),np.log10(energy)))
        rows.append({'law':name,'dimension':len(d),'eta':e,'energy':energy,'amplitude':float(d[0])})
        if len(d)==2:break
        aa=e/((1+e)*np.sqrt(1+e*e));tt=float(d[:-1]@d[:-1]/(d@d));g=func(2*aa*aa*tt)
        d=np.sqrt(2)*aa/(1+g)*d[:-1];e=g
    pts=np.asarray(points);ax.plot(pts[:,0],pts[:,1],pts[:,2],'-o',color=color,label=name,linewidth=2,markersize=5)
ax.set(xlabel='Carrier dimension',ylabel=r'$\log_{10}\eta$',zlabel=r'$\log_{10}E$')
ax.set_xticks([2,3,4,5]);ax.view_init(25,-57);ax.legend(loc='upper left',fontsize=9)
save(fig,'Figure_3_finite_trajectories_3D')
(DATA/'finite_trajectories.json').write_text(json.dumps(rows,indent=2)+'\n')
ref=[r for r in rows if r['law']=='q']
assert np.isclose(ref[1]['eta'],.2) and np.isclose(ref[1]['energy'],5/6)

rp=ROOT/'rlc'
raw=json.loads((rp/'rlc_circuit.json').read_text());res=json.loads((rp/'RESULTS.json').read_text())
f=np.asarray(raw['f']);z=np.asarray(raw['z_real'])+1j*np.asarray(raw['z_imag']);ix=np.argsort(f);f=f[ix];z=z[ix]
r,l,c=res['fitted_parameters'].values(); f_model=np.geomspace(f.min(),f.max(),1800);w=2*np.pi*f_model
zm=(r+1j*w*l)/(1+1j*w*c*(r+1j*w*l))
fig=plt.figure(figsize=(7.2,4.8));ax=fig.add_subplot(111,projection='3d')
ax.plot(np.log10(f_model),zm.real,zm.imag,color='#176B87',label='Conventional RLC fit',linewidth=1.7)
ax.scatter(np.log10(f),z.real,z.imag,color='#D66A1F',s=11,label='Measured spectrum',depthshade=False)
ax.set(xlabel=r'$\log_{10}(f/\mathrm{Hz})$',ylabel=r'Re Z ($\Omega$)',zlabel=r'Im Z ($\Omega$)')
ax.view_init(24,-127);ax.legend(loc='upper left',fontsize=9)
save(fig,'Figure_4_RLC_spectrum_3D')

manifest={'grid_points':int(q.size),'eta_range':[.05,4.],'t_range':[.02,.98],'maximum_sampled_q':float(q.max()),'simulation_kind':'deterministic finite SA parameter sweep; not empirical data','trajectory_laws':3,'trajectory_states':len(rows),'numpy':np.__version__,'matplotlib':matplotlib.__version__,'randomness':'none','RLC_source_sha256':res['source_sha256'],'RLC_fitted_parameters':res['fitted_parameters'],'RLC_check':res['fitted_interpolation_check']}
(DATA/'RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
